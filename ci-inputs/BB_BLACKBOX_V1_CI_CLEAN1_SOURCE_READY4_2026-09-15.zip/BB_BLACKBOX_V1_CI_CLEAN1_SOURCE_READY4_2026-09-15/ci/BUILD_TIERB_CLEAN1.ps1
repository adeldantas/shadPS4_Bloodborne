param(
    [string]$SourceRoot = (Get-Location).Path,
    [string]$BuildRoot = ""
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

if (-not $BuildRoot) {
    $BuildRoot = Join-Path $SourceRoot "build-clean1"
}

$Clang = "C:\LLVM19\bin\clang-cl.exe"
if (-not (Test-Path $Clang)) {
    throw "Pinned compiler missing: $Clang"
}

# Remove the contamination class that already broke previous builds.
foreach ($name in @("CPATH", "CPLUS_INCLUDE_PATH", "C_INCLUDE_PATH")) {
    [Environment]::SetEnvironmentVariable($name, $null, "Process")
}
$pathParts = $env:PATH -split ';' | Where-Object {
    $_ -and ($_ -notmatch '(?i)\\msys64\\') -and ($_ -notmatch '(?i)\\mingw')
}
$env:PATH = (($pathParts | Select-Object -Unique) -join ';')

$bad = @()
foreach ($name in @("CPATH", "CPLUS_INCLUDE_PATH", "C_INCLUDE_PATH", "INCLUDE", "LIB", "LIBPATH", "PATH")) {
    $v = [Environment]::GetEnvironmentVariable($name, "Process")
    if ($v -and $v -match '(?i)msys|mingw') {
        $bad += "$name=$v"
    }
}
if ($bad.Count -gt 0) {
    throw ("MinGW/MSYS contamination remains after sanitization:`n" + ($bad -join "`n"))
}

$clangVersion = (& $Clang --version | Out-String)
if ($clangVersion -notmatch 'clang version 19\.1\.1') {
    throw "Pinned clang-cl is not 19.1.1:`n$clangVersion"
}

$CMake = (Get-Command cmake.exe -ErrorAction Stop).Source
$Ninja = (Get-Command ninja.exe -ErrorAction Stop).Source
$CMakeVersion = (& $CMake --version | Out-String)
$NinjaVersion = (& $Ninja --version | Out-String)

@(
    "source_root=$SourceRoot"
    "build_root=$BuildRoot"
    "clang=$Clang"
    "cmake=$CMake"
    "ninja=$Ninja"
    "qt_root=$env:QT_ROOT_DIR"
    "clang_version=$($clangVersion.Trim())"
    "cmake_version=$($CMakeVersion.Trim())"
    "ninja_version=$($NinjaVersion.Trim())"
) | Out-File clean1_toolchain.txt -Encoding utf8

if (Test-Path $BuildRoot) {
    Remove-Item -Recurse -Force $BuildRoot
}

# Use an argument array so PowerShell never sends a literal '$NinjaExe' to CMake.
$args = @(
    "--fresh"
    "-S", $SourceRoot
    "-B", $BuildRoot
    "-G", "Ninja"
    "-DCMAKE_BUILD_TYPE=Release"
    "-DENABLE_QT_GUI=ON"
    "-DENABLE_UPDATER=ON"
    "-DCMAKE_INTERPROCEDURAL_OPTIMIZATION_RELEASE=ON"
    "-DCMAKE_C_COMPILER=$Clang"
    "-DCMAKE_CXX_COMPILER=$Clang"
    "-DCMAKE_ASM_COMPILER=$Clang"
    "-DCMAKE_MAKE_PROGRAM=$Ninja"
)

if ($env:QT_ROOT_DIR) {
    $args += "-DCMAKE_PREFIX_PATH=$env:QT_ROOT_DIR"
}

Write-Host "CONFIGURE: $CMake $($args -join ' ')"
& $CMake @args 2>&1 | Tee-Object clean1_cmake_configure.log
if ($LASTEXITCODE -ne 0) {
    throw "CMake configure failed: $LASTEXITCODE"
}

# CMake cache is evidence. Reject compiler drift immediately.
$cache = Join-Path $BuildRoot "CMakeCache.txt"
if (-not (Test-Path $cache)) {
    throw "CMakeCache.txt missing after configure"
}
$cacheText = Get-Content $cache -Raw
if ($cacheText -notmatch [regex]::Escape("C:\LLVM19\bin\clang-cl.exe")) {
    throw "CMake cache did not retain pinned clang-cl path"
}
if ($cacheText -match '(?i)msys|mingw') {
    throw "CMake cache contains MinGW/MSYS contamination"
}

Write-Host "BUILD"
& $CMake --build $BuildRoot --config Release --parallel $env:NUMBER_OF_PROCESSORS 2>&1 |
    Tee-Object clean1_build.log
if ($LASTEXITCODE -ne 0) {
    throw "CMake build failed: $LASTEXITCODE"
}

$Exe = Get-ChildItem -Path $BuildRoot -Recurse -Filter "shadPS4.exe" | Select-Object -First 1
if (-not $Exe) {
    throw "shadPS4.exe not produced"
}

$Recorder = Get-ChildItem -Path $BuildRoot -Recurse -Filter "bb_blackbox_recorder.exe" | Select-Object -First 1
if (-not $Recorder) {
    throw "bb_blackbox_recorder.exe not produced"
}

Get-FileHash $Exe.FullName -Algorithm SHA256 |
    Format-List | Out-File clean1_output_hashes.txt -Encoding utf8
Get-FileHash $Recorder.FullName -Algorithm SHA256 |
    Format-List | Out-File clean1_output_hashes.txt -Append -Encoding utf8

# Preserve exact compiler commands / generated source metadata when available.
if (Test-Path (Join-Path $BuildRoot "compile_commands.json")) {
    Copy-Item (Join-Path $BuildRoot "compile_commands.json") clean1_compile_commands.json -Force
}

Write-Host "CLEAN1 Tier-B build completed"
Write-Host "shadPS4: $($Exe.FullName)"
Write-Host "recorder: $($Recorder.FullName)"
