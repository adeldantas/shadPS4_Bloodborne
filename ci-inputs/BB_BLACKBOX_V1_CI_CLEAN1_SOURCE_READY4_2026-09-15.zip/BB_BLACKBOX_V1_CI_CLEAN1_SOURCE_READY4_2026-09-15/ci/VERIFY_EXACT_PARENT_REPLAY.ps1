param(
    [string]$SourceRoot = (Get-Location).Path,
    [string]$ParentPatch = "ci\\evidence\\INTEGRATED_R3_SAVEFIX_S1.patch",
    [string]$IntegrationPatch = "ci\\evidence\\BLACKBOX_V1_CI_CLEAN1_CORE_SAFE.patch"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Baseline = "03d62ad22438344f1dcd38c5b5e44f660b564b92"
$ParentSha256 = "92ee02584cae06cc4feace76dcbfdaadcca225e3a005b1038246850fa154c485"
$SourceRoot = (Resolve-Path $SourceRoot).Path
$ParentPatch = (Resolve-Path (Join-Path $SourceRoot $ParentPatch)).Path
$IntegrationPatch = (Resolve-Path (Join-Path $SourceRoot $IntegrationPatch)).Path

$actual = (Get-FileHash $ParentPatch -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $ParentSha256) {
    throw "Exact-parent evidence hash mismatch. Expected $ParentSha256, got $actual"
}

& git -C $SourceRoot cat-file -e "$Baseline^{commit}"
if ($LASTEXITCODE -ne 0) { throw "Frozen baseline commit is unavailable in checkout." }

$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("bb-clean1-replay-" + [guid]::NewGuid().ToString("N"))
$added = $false
try {
    & git -C $SourceRoot worktree add --detach $TempRoot $Baseline
    if ($LASTEXITCODE -ne 0) { throw "Failed to create exact-baseline replay worktree." }
    $added = $true

    & git -C $TempRoot apply --check $ParentPatch
    if ($LASTEXITCODE -ne 0) { throw "Exact R3-SAVEFIX-S1 parent does not apply to frozen baseline." }
    & git -C $TempRoot apply $ParentPatch
    if ($LASTEXITCODE -ne 0) { throw "Failed to apply exact R3-SAVEFIX-S1 parent in replay." }

    # Integration patch references these new files from CMake but does not create them itself.
    $newFiles = @(
        "src/common/bb_blackbox/schema.h",
        "src/common/bb_blackbox/sites.h",
        "src/common/bb_blackbox/recorder.h",
        "src/common/bb_blackbox/recorder.cpp",
        "src/common/bb_blackbox/identity.h",
        "src/common/bb_blackbox/identity.cpp",
        "src/video_core/renderer_vulkan/bb_gpu_trace.h",
        "src/video_core/renderer_vulkan/bb_gpu_trace.cpp",
        "tools/bb_blackbox/recorder_main.cpp",
        "tools/bb_blackbox/decode.py",
        "tools/bb_blackbox/run_blackbox.cmd"
    )
    foreach ($rel in $newFiles) {
        $src = Join-Path $SourceRoot $rel
        if (-not (Test-Path $src)) { throw "Replay source missing required CLEAN1 file: $rel" }
        $dst = Join-Path $TempRoot $rel
        if (Test-Path $dst) { throw "Replay would overwrite baseline/parent file: $rel" }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        Copy-Item $src $dst
    }

    & python (Join-Path $SourceRoot "ci\\verify_patch_structure.py") $IntegrationPatch
    if ($LASTEXITCODE -ne 0) { throw "Integration patch structure gate failed in replay." }

    & git -C $TempRoot apply --check $IntegrationPatch
    if ($LASTEXITCODE -ne 0) { throw "CLEAN1 integration patch does not apply to exact replayed parent." }

    @(
        "EXACT_PARENT_SHA256=$actual"
        "EXACT_PARENT_REPLAY_BASELINE=$Baseline"
        "EXACT_PARENT_APPLY_CHECK=PASS"
        "CLEAN1_INTEGRATION_APPLY_CHECK=PASS"
    ) | Out-File (Join-Path $SourceRoot "clean1_exact_parent_replay.txt") -Encoding utf8

    Write-Host "CLEAN1_EXACT_PARENT_REPLAY_PASS=true"
}
finally {
    if ($added) {
        & git -C $SourceRoot worktree remove --force $TempRoot | Out-Null
    }
    if (Test-Path $TempRoot) {
        Remove-Item -Recurse -Force $TempRoot -ErrorAction SilentlyContinue
    }
}
