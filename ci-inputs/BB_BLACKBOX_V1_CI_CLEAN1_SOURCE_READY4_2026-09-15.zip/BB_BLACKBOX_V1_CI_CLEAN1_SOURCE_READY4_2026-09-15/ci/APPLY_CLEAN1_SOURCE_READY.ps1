param(
    [Parameter(Mandatory=$true)][string]$RepoRoot,
    [string]$ParentPatch = ""
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Baseline = "03d62ad22438344f1dcd38c5b5e44f660b564b92"
$ParentSha256 = "92ee02584cae06cc4feace76dcbfdaadcca225e3a005b1038246850fa154c485"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$Overlay = Join-Path $PackageRoot "overlay"
$IntegrationPatch = Join-Path $PackageRoot "integration\BLACKBOX_V1_CI_CLEAN1_CORE_SAFE.patch"
if ([string]::IsNullOrWhiteSpace($ParentPatch)) {
    $ParentPatch = Join-Path $PackageRoot "evidence\accepted_parent\INTEGRATED_R3_SAVEFIX_S1.patch"
}
$ParentPatch = (Resolve-Path $ParentPatch).Path

$PatchVerifier = Join-Path $PackageRoot "ci\verify_patch_structure.py"
& python $PatchVerifier $IntegrationPatch
if ($LASTEXITCODE -ne 0) { throw "CLEAN1 integration patch structure gate failed." }

Push-Location $RepoRoot
try {
    $head = (git rev-parse HEAD).Trim()
    if ($LASTEXITCODE -ne 0 -or $head -ne $Baseline) {
        throw "Wrong HEAD. Expected frozen baseline $Baseline, got $head"
    }

    if (git status --porcelain) {
        throw "Repository must be clean before CLEAN1 reconstruction."
    }

    $actualParentHash = (Get-FileHash $ParentPatch -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualParentHash -ne $ParentSha256) {
        throw "Parent patch hash mismatch. Expected $ParentSha256, got $actualParentHash"
    }

    $evidenceDir = Join-Path $RepoRoot "ci\evidence"
    New-Item -ItemType Directory -Force -Path $evidenceDir | Out-Null
    Copy-Item $ParentPatch (Join-Path $evidenceDir "INTEGRATED_R3_SAVEFIX_S1.patch") -Force
    Copy-Item $IntegrationPatch (Join-Path $evidenceDir "BLACKBOX_V1_CI_CLEAN1_CORE_SAFE.patch") -Force

    git apply --check $ParentPatch
    if ($LASTEXITCODE -ne 0) { throw "Accepted R3-SAVEFIX-S1 parent does not apply cleanly." }
    git apply $ParentPatch
    if ($LASTEXITCODE -ne 0) { throw "Failed applying accepted R3-SAVEFIX-S1 parent." }

    $newFiles = @(
        "src/common/bb_blackbox/schema.h",
        "src/common/bb_blackbox/sites.h",
        "src/common/bb_blackbox/recorder.h",
        "src/common/bb_blackbox/recorder.cpp",
        "src/common/bb_blackbox/identity.h",
        "src/common/bb_blackbox/identity.cpp",
        "src/video_core/renderer_vulkan/bb_gpu_trace.h",
        "src/video_core/renderer_vulkan/bb_gpu_trace.cpp",
        "tools/bb_blackbox/recorder_main.cpp",
        "tools/bb_blackbox/decode.py",
        "tools/bb_blackbox/run_blackbox.cmd"
    )

    foreach ($rel in $newFiles) {
        $dst = Join-Path $RepoRoot $rel
        if (Test-Path $dst) {
            throw "Refusing to overwrite existing CLEAN1 source: $rel"
        }
        $src = Join-Path $Overlay $rel
        if (-not (Test-Path $src)) {
            throw "SOURCE_READY package missing overlay file: $rel"
        }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        Copy-Item $src $dst
    }

    git apply --check $IntegrationPatch
    if ($LASTEXITCODE -ne 0) {
        throw "CLEAN1 integration patch does not apply cleanly to the reconstructed parent."
    }
    git apply $IntegrationPatch
    if ($LASTEXITCODE -ne 0) { throw "Failed applying CLEAN1 integration patch." }

    # CI/gates are tracked support files, not runtime code.
    foreach ($rel in @(
        "ci/verify_clean1.py",
        "ci/test_verify_clean1.py",
        "ci/verify_patch_structure.py",
        "ci/VERIFY_EXACT_PARENT_REPLAY.ps1",
        "ci/INSTALL_LLVM_CLEAN1.ps1",
        "ci/BUILD_TIERB_CLEAN1.ps1"
    )) {
        $src = Join-Path $PackageRoot $rel
        if (Test-Path $src) {
            $dst = Join-Path $RepoRoot $rel
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
            Copy-Item $src $dst -Force
        }
    }

    $wfSrc = Join-Path $PackageRoot ".github\workflows\blackbox-clean1.yml"
    if (Test-Path $wfSrc) {
        $wfDst = Join-Path $RepoRoot ".github\workflows\blackbox-clean1.yml"
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $wfDst) | Out-Null
        Copy-Item $wfSrc $wfDst -Force
    }

    python tools/bb_blackbox/decode.py --self-test
    if ($LASTEXITCODE -ne 0) { throw "Decoder protocol self-test failed." }

    python ci/verify_clean1.py . --json clean1_static_audit.json
    if ($LASTEXITCODE -ne 0) { throw "CLEAN1 semantic gate failed." }

    git status --porcelain | Out-File clean1_source_status.txt -Encoding utf8

    # Include untracked CLEAN1 source/evidence in the archived diff without staging content.
    git add -N -- src/common/bb_blackbox src/video_core/renderer_vulkan/bb_gpu_trace.h `
        src/video_core/renderer_vulkan/bb_gpu_trace.cpp tools/bb_blackbox ci .github/workflows/blackbox-clean1.yml
    if ($LASTEXITCODE -ne 0) { throw "Failed to expose untracked CLEAN1 files to diff evidence." }
    git diff --binary $Baseline -- . | Out-File clean1_full_source_diff.patch -Encoding utf8
    git reset --quiet
    if ($LASTEXITCODE -ne 0) { throw "Failed restoring index after diff evidence generation." }

    Write-Host "BLACKBOX_V1_CI_CLEAN1_SOURCE_APPLIED=true"
    Write-Host "Next gate: deterministic windows-2022 Tier-B build."
}
finally {
    Pop-Location
}
