param(
    [string]$InstallRoot = "C:\LLVM19"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Version = "19.1.1"
$ExpectedSha256 = "95f03b6a8a0049e29898b0fadf84a0ea252f2e7f1b36db15a81aae11e912f675"
$Url = "https://github.com/llvm/llvm-project/releases/download/llvmorg-19.1.1/LLVM-19.1.1-win64.exe"
$Installer = Join-Path $env:RUNNER_TEMP "LLVM-19.1.1-win64.exe"

Write-Host "CLEAN1 LLVM source: $Url"
Invoke-WebRequest -Uri $Url -OutFile $Installer -UseBasicParsing

$fi = Get-Item $Installer
if ($fi.Length -ne 351794030) {
    throw "Unexpected LLVM installer size: $($fi.Length), expected 351794030"
}

$hash = (Get-FileHash $Installer -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne $ExpectedSha256) {
    throw "LLVM installer SHA256 mismatch. Expected $ExpectedSha256, got $hash"
}
"llvm_installer_url=$Url" | Out-File clean1_llvm_identity.txt -Encoding utf8
"llvm_installer_size=$($fi.Length)" | Out-File clean1_llvm_identity.txt -Append -Encoding utf8
"llvm_installer_sha256=$hash" | Out-File clean1_llvm_identity.txt -Append -Encoding utf8

if (Test-Path $InstallRoot) {
    Remove-Item -Recurse -Force $InstallRoot
}

# LLVM's official Windows installer is NSIS. /S is silent and /D must be the final argument.
$p = Start-Process -FilePath $Installer -ArgumentList @("/S", "/D=$InstallRoot") -Wait -PassThru
if ($p.ExitCode -ne 0) {
    throw "LLVM installer failed with exit code $($p.ExitCode)"
}

$Clang = Join-Path $InstallRoot "bin\clang-cl.exe"
if (-not (Test-Path $Clang)) {
    throw "clang-cl.exe missing after LLVM installation: $Clang"
}

$versionText = (& $Clang --version | Out-String)
$versionText | Out-File clean1_clang_version.txt -Encoding utf8
if ($versionText -notmatch 'clang version 19\.1\.1') {
    throw "Wrong clang-cl version. Expected 19.1.1. Got: $versionText"
}

Write-Host "LLVM 19.1.1 installation verified: $Clang"
