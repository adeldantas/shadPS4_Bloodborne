// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include <array>
#include <cstdint>

#include "common/bb_blackbox/schema.h"
#include "common/bb_blackbox/sites.h"
#include "video_core/renderer_vulkan/vk_platform.h"

namespace Vulkan {

class Instance;

class BlackboxGpuTrace {
public:
    explicit BlackboxGpuTrace(const Instance& instance);
    ~BlackboxGpuTrace();

    bool Enabled() const noexcept { return enabled_; }
    std::uint32_t QueueId() const noexcept { return queue_id_; }
    std::uint32_t SchedulerId() const noexcept { return scheduler_id_; }

    void BeginCommandBuffer(vk::CommandBuffer cmdbuf, std::uint64_t command_buffer_id);
    void BeforeSubmit(vk::CommandBuffer cmdbuf, std::uint64_t tick, std::uint64_t submit_id);
    void Poll(std::uint64_t known_gpu_tick);

    std::uint32_t BeginRegion(vk::CommandBuffer cmdbuf, Common::Blackbox::GpuCategory category,
                              Common::Blackbox::Site site, std::uint64_t bytes = 0,
                              std::uint64_t resource_token = 0);
    void EndRegion(vk::CommandBuffer cmdbuf, std::uint32_t token);

private:
    static constexpr std::uint32_t QueryCount = 8192;
    static constexpr std::uint32_t PairCount = QueryCount / 2;
    static constexpr std::uint32_t MaxActivePerCommandBuffer = 128;
    static constexpr std::uint32_t InvalidToken = 0xFFFFFFFFu;

    enum class SlotState : std::uint8_t { Free, Active, Pending };

    struct Slot {
        SlotState state{SlotState::Free};
        std::uint16_t category{};
        std::uint16_t site{};
        std::uint32_t first_query{};
        std::uint64_t region_op_id{};
        std::uint64_t bytes{};
        std::uint64_t resource_token{};
        std::uint64_t command_buffer_id{};
        std::uint64_t submit_id{};
        std::uint64_t tick{};
        std::uint32_t frame_hint{};
        std::uint32_t read_attempts{};
        bool ended{};
    };

    std::uint32_t AcquirePair(vk::CommandBuffer cmdbuf,
                              Common::Blackbox::GpuCategory category,
                              Common::Blackbox::Site site, std::uint64_t bytes,
                              std::uint64_t resource_token, bool sampled);
    void ReleasePair(std::uint32_t slot_index) noexcept;
    bool TimestampBudgetAllows(std::uint32_t writes) noexcept;
    void PushPending(std::uint32_t slot_index) noexcept;

private:
    const Instance& instance_;
    vk::UniqueQueryPool query_pool_{};

    std::array<Slot, PairCount> slots_{};
    std::array<std::uint16_t, PairCount> free_stack_{};
    std::uint32_t free_count_{};

    std::array<std::uint16_t, PairCount> pending_ring_{};
    std::uint32_t pending_head_{};
    std::uint32_t pending_tail_{};
    std::uint32_t pending_count_{};

    std::array<std::uint16_t, MaxActivePerCommandBuffer> active_{};
    std::uint32_t active_count_{};

    std::uint64_t current_command_buffer_id_{};
    std::uint64_t budget_window_qpc_{};
    std::uint32_t budget_writes_{};

    std::uint32_t queue_id_{};
    std::uint32_t scheduler_id_{};
    std::uint32_t timestamp_valid_bits_{};
    float timestamp_period_{};
    bool enabled_{};
};

} // namespace Vulkan
