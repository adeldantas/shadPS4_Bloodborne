// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include "video_core/renderer_vulkan/bb_gpu_trace.h"

#include <array>
#include <atomic>
#include <bit>
#include <cstdint>

#include "common/bb_blackbox/recorder.h"
#include "video_core/renderer_vulkan/vk_instance.h"

namespace Vulkan {
namespace {

std::atomic<std::uint32_t> next_scheduler_id{1};

std::uint32_t QueueToken(vk::Queue queue) noexcept {
    const auto raw = reinterpret_cast<std::uintptr_t>(static_cast<VkQueue>(queue));
    const std::uint64_t value = static_cast<std::uint64_t>(raw);
    return static_cast<std::uint32_t>(value ^ (value >> 32));
}

} // namespace

BlackboxGpuTrace::BlackboxGpuTrace(const Instance& instance) : instance_{instance} {
    scheduler_id_ = next_scheduler_id.fetch_add(1, std::memory_order_relaxed);
    queue_id_ = QueueToken(instance_.GetGraphicsQueue());

    const auto properties = instance_.GetPhysicalDevice().getProperties();
    timestamp_period_ = properties.limits.timestampPeriod;

    const auto qprops = instance_.GetPhysicalDevice().getQueueFamilyProperties();
    const std::uint32_t family = instance_.GetGraphicsQueueFamilyIndex();
    if (family >= qprops.size()) {
        return;
    }
    timestamp_valid_bits_ = qprops[family].timestampValidBits;
    if (timestamp_valid_bits_ == 0) {
        return;
    }

    const vk::QueryPoolCreateInfo create_info{
        .queryType = vk::QueryType::eTimestamp,
        .queryCount = QueryCount,
    };
    auto [result, pool] = instance_.GetDevice().createQueryPoolUnique(create_info);
    if (result != vk::Result::eSuccess) {
        return;
    }
    query_pool_ = std::move(pool);

    free_count_ = PairCount;
    for (std::uint32_t i = 0; i < PairCount; ++i) {
        free_stack_[i] = static_cast<std::uint16_t>(PairCount - 1 - i);
        slots_[i].first_query = i * 2;
    }

    enabled_ = true;

    auto& rec = Common::Blackbox::Recorder::Instance();
    rec.Emit(Common::Blackbox::EventId::Capability, Common::Blackbox::Site::GpuCommandBufferEnvelope,
             Common::Blackbox::EventFlags::Success, Common::Blackbox::PayloadKind::GpuRegion,
             timestamp_valid_bits_, std::bit_cast<std::uint32_t>(timestamp_period_), queue_id_);
}

BlackboxGpuTrace::~BlackboxGpuTrace() {
    if (pending_count_ != 0) {
        Common::Blackbox::Recorder::Instance().CountLoss(
            Common::Blackbox::LossKind::GpuQueryUnresolvedOnShutdown, pending_count_);
    }
}

bool BlackboxGpuTrace::TimestampBudgetAllows(std::uint32_t writes) noexcept {
    auto& rec = Common::Blackbox::Recorder::Instance();
    const std::uint64_t now = rec.QpcNow();
    const std::uint64_t freq = rec.QpcFrequency();
    if (budget_window_qpc_ == 0 || now - budget_window_qpc_ >= freq) {
        budget_window_qpc_ = now;
        budget_writes_ = 0;
    }
    if (budget_writes_ + writes > 8192) {
        rec.CountLoss(Common::Blackbox::LossKind::GpuTimestampBudget);
        return false;
    }
    budget_writes_ += writes;
    return true;
}

std::uint32_t BlackboxGpuTrace::AcquirePair(
    vk::CommandBuffer cmdbuf, Common::Blackbox::GpuCategory category,
    Common::Blackbox::Site site, std::uint64_t bytes, std::uint64_t resource_token,
    bool sampled) {
    if (!enabled_ || free_count_ == 0 || active_count_ >= MaxActivePerCommandBuffer) {
        auto& rec = Common::Blackbox::Recorder::Instance();
        rec.CountLoss(free_count_ == 0 ? Common::Blackbox::LossKind::GpuQueryExhausted
                                      : Common::Blackbox::LossKind::ActiveGpuRegionExhausted);
        return InvalidToken;
    }
    if (!TimestampBudgetAllows(2)) {
        return InvalidToken;
    }

    const std::uint32_t slot_index = free_stack_[--free_count_];
    auto& slot = slots_[slot_index];
    slot.state = SlotState::Active;
    slot.category = static_cast<std::uint16_t>(category);
    slot.site = static_cast<std::uint16_t>(site);
    slot.bytes = bytes;
    slot.resource_token = resource_token;
    slot.command_buffer_id = current_command_buffer_id_;
    slot.submit_id = 0;
    slot.tick = 0;
    slot.frame_hint = Common::Blackbox::Recorder::Instance().CurrentFrameHint();
    slot.read_attempts = 0;
    slot.ended = false;

    cmdbuf.resetQueryPool(*query_pool_, slot.first_query, 2);
    cmdbuf.writeTimestamp2(vk::PipelineStageFlagBits2::eTopOfPipe, *query_pool_, slot.first_query);

    const auto flags = Common::Blackbox::EventFlags::Begin |
                       (sampled ? Common::Blackbox::EventFlags::Sampled
                                : Common::Blackbox::EventFlags::None);
    slot.region_op_id = Common::Blackbox::Recorder::Instance().Emit(
        Common::Blackbox::EventId::GpuRegion, site, flags,
        Common::Blackbox::PayloadKind::GpuRegion,
        static_cast<std::uint64_t>(category), bytes, resource_token);

    active_[active_count_++] = static_cast<std::uint16_t>(slot_index);
    return slot_index;
}

void BlackboxGpuTrace::ReleasePair(std::uint32_t slot_index) noexcept {
    if (slot_index >= PairCount) {
        return;
    }
    slots_[slot_index] = Slot{.first_query = slot_index * 2};
    free_stack_[free_count_++] = static_cast<std::uint16_t>(slot_index);
}

void BlackboxGpuTrace::PushPending(std::uint32_t slot_index) noexcept {
    // pending_count cannot exceed PairCount because pending slots are not in free_stack_.
    if (pending_count_ >= PairCount) {
        Common::Blackbox::Recorder::Instance().CountLoss(
            Common::Blackbox::LossKind::GpuQueryExhausted);
        return;
    }
    pending_ring_[pending_tail_] = static_cast<std::uint16_t>(slot_index);
    pending_tail_ = (pending_tail_ + 1) % PairCount;
    ++pending_count_;
}

void BlackboxGpuTrace::BeginCommandBuffer(vk::CommandBuffer cmdbuf,
                                          std::uint64_t command_buffer_id) {
    current_command_buffer_id_ = command_buffer_id;
    active_count_ = 0;
    (void)AcquirePair(cmdbuf, Common::Blackbox::GpuCategory::CommandBufferEnvelope,
                      Common::Blackbox::Site::GpuCommandBufferEnvelope, 0, 0, true);
}

std::uint32_t BlackboxGpuTrace::BeginRegion(
    vk::CommandBuffer cmdbuf, Common::Blackbox::GpuCategory category,
    Common::Blackbox::Site site, std::uint64_t bytes, std::uint64_t resource_token) {
    return AcquirePair(cmdbuf, category, site, bytes, resource_token, true);
}

void BlackboxGpuTrace::EndRegion(vk::CommandBuffer cmdbuf, std::uint32_t token) {
    if (!enabled_ || token == InvalidToken || token >= PairCount) {
        return;
    }
    auto& slot = slots_[token];
    if (slot.state != SlotState::Active || slot.ended) {
        return;
    }
    cmdbuf.writeTimestamp2(vk::PipelineStageFlagBits2::eAllCommands, *query_pool_,
                           slot.first_query + 1);
    slot.ended = true;
}

void BlackboxGpuTrace::BeforeSubmit(vk::CommandBuffer cmdbuf, std::uint64_t tick,
                                    std::uint64_t submit_id) {
    if (!enabled_) {
        return;
    }

    // Close every region belonging to this command buffer without inserting any barrier/wait.
    for (std::uint32_t i = 0; i < active_count_; ++i) {
        const std::uint32_t slot_index = active_[i];
        auto& slot = slots_[slot_index];
        if (!slot.ended) {
            EndRegion(cmdbuf, slot_index);
        }
        slot.tick = tick;
        slot.submit_id = submit_id;
        slot.state = SlotState::Pending;

        Common::Blackbox::Recorder::Instance().EmitWithContext(
            Common::Blackbox::EventId::GpuRegion,
            static_cast<Common::Blackbox::Site>(slot.site),
            Common::Blackbox::EventFlags::End | Common::Blackbox::EventFlags::Sampled,
            Common::Blackbox::PayloadKind::GpuRegion, slot.region_op_id, slot.frame_hint,
            slot.command_buffer_id, slot.submit_id, slot.tick);

        PushPending(slot_index);
    }
    active_count_ = 0;
}

void BlackboxGpuTrace::Poll(std::uint64_t known_gpu_tick) {
    if (!enabled_ || pending_count_ == 0) {
        return;
    }

    // Only completed timeline ticks are queried. No WAIT_BIT, no waitIdle and no Finish.
    while (pending_count_ != 0) {
        const std::uint32_t slot_index = pending_ring_[pending_head_];
        auto& slot = slots_[slot_index];
        if (slot.tick > known_gpu_tick) {
            break;
        }

        std::array<std::uint64_t, 4> values{};
        const auto flags =
            vk::QueryResultFlagBits::e64 | vk::QueryResultFlagBits::eWithAvailability;
        const vk::Result result = instance_.GetDevice().getQueryPoolResults(
            *query_pool_, slot.first_query, 2, sizeof(values), values.data(),
            sizeof(std::uint64_t) * 2, flags);

        ++slot.read_attempts;
        const bool available = result == vk::Result::eSuccess && values[1] != 0 && values[3] != 0;
        if (!available) {
            if (result != vk::Result::eSuccess && result != vk::Result::eNotReady) {
                Common::Blackbox::Recorder::Instance().CountLoss(
                    Common::Blackbox::LossKind::GpuQueryReadError);
                pending_head_ = (pending_head_ + 1) % PairCount;
                --pending_count_;
                ReleasePair(slot_index);
                continue;
            }
            // Timeline completion should normally imply timestamp availability, but do not spin/wait.
            break;
        }

        Common::Blackbox::Recorder::Instance().EmitWithContext(
            Common::Blackbox::EventId::GpuQueryResult,
            static_cast<Common::Blackbox::Site>(slot.site),
            Common::Blackbox::EventFlags::Available | Common::Blackbox::EventFlags::Sampled,
            Common::Blackbox::PayloadKind::TickPair, slot.region_op_id, slot.frame_hint,
            (static_cast<std::uint64_t>(queue_id_) << 32) |
                (static_cast<std::uint64_t>(slot.category) << 16) |
                static_cast<std::uint64_t>(timestamp_valid_bits_ & 0xFFFFu),
            values[0], values[2]);

        pending_head_ = (pending_head_ + 1) % PairCount;
        --pending_count_;
        ReleasePair(slot_index);
    }
}

} // namespace Vulkan
