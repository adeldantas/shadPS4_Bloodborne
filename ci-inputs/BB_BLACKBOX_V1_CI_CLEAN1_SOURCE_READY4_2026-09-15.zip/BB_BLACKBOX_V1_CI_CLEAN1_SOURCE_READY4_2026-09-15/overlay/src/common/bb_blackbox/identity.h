// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

namespace Common::Blackbox {

// Startup-only identity marker. Full effective game/profile validation remains a later gate.
void EmitCoreIdentityOnce() noexcept;

} // namespace Common::Blackbox
