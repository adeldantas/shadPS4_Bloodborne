// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include <cstddef>
#include <cstdint>

namespace Common::Blackbox {

inline constexpr std::uint32_t SchemaMajor = 1;
inline constexpr std::uint32_t SchemaMinor = 0;
inline constexpr std::uint64_t SharedMagic = 0x314D485342584242ULL; // "BBXBSHM1"
inline constexpr std::uint64_t ChunkMagic = 0x314B4E4843584242ULL;  // "BBXCHNK1"
inline constexpr std::uint64_t TrailerMagic = 0x31524C5254584242ULL; // "BBXTRLR1"

inline constexpr std::uint32_t ThreadSlotCount = 64;
inline constexpr std::uint32_t EventsPerThread = 4096;
inline constexpr std::uint32_t EventBytes = 64;
inline constexpr std::uint32_t MaxChunkEvents = 1022;

enum class EventId : std::uint16_t {
    Session = 1,
    Config = 2,
    Capability = 3,

    FrameSubmit = 10,
    FrameReady = 11,
    FramePresent = 12,
    FrameDisplay = 13,

    CpuScopeBegin = 20,
    CpuScopeEnd = 21,

    Finish = 30,
    Wait = 31,
    Flush = 32,
    Submit = 33,

    CpuFault = 40,
    PageProtect = 41,

    ReadbackRequest = 50,
    ReadbackCopy = 51,
    BackingCommit = 52,

    GpuRegion = 70,
    GpuQueryResult = 71,
    GpuBarrier = 72,

    Resource = 80,
    Allocation = 81,
    Residency = 82,

    Pressure = 92,
    Shader = 100,
    Pipeline = 101,
    FetchParse = 102,

    ProcessSample = 121,

    Snapshot = 240,
    Crash = 241,
    DeviceLost = 242,

    Loss = 250,
    Heartbeat = 251,
    RecorderCost = 252,
};

enum class EventFlags : std::uint16_t {
    None = 0,
    Begin = 1U << 0,
    End = 1U << 1,
    Success = 1U << 2,
    Available = 1U << 3,
    Truncated = 1U << 4,
    Sampled = 1U << 5,
    DroppedNeighbor = 1U << 6,
    Unverified = 1U << 7,
    Crash = 1U << 8,
    ReusedFrame = 1U << 9,
    Unknown = 1U << 10,
};

constexpr EventFlags operator|(EventFlags a, EventFlags b) noexcept {
    return static_cast<EventFlags>(static_cast<std::uint16_t>(a) |
                                   static_cast<std::uint16_t>(b));
}

constexpr bool HasFlag(EventFlags value, EventFlags flag) noexcept {
    return (static_cast<std::uint16_t>(value) & static_cast<std::uint16_t>(flag)) != 0;
}

enum class PayloadKind : std::uint16_t {
    None = 0,
    DurationQpc = 1,
    Bytes = 2,
    TickPair = 3,
    Readback = 4,
    Frame = 5,
    GpuRegion = 6,
    Loss = 7,
};

enum class GpuCategory : std::uint16_t {
    UnknownGpu = 0,
    CommandBufferEnvelope = 1,
    GuestGraphics = 2,
    GuestCompute = 3,
    GuestHleClearCopy = 4,
    EmuUpload = 5,
    EmuBufferCopy = 6,
    EmuReadback = 7,
    EmuDetile = 8,
    EmuRetile = 9,
    EmuAlias = 10,
    EmuFaultHelper = 11,
    HostFsrPp = 12,
    HostPresentUi = 13,
};

enum class Reason : std::uint16_t {
    Unknown = 0,
    CpuReadFault = 1,
    CpuWritePreserve = 2,
    UnmapPreserve = 3,
    Pm4SelfMod = 4,
    Pm4ExplicitRead = 5,
    ImageEdge = 6,
    PreemptiveBuffer = 7,
    BufferStagingReuse = 8,
    CommandPoolReuse = 9,
    GuestIdle = 10,
    PresentFrameReuse = 11,
    PresentAcquire = 12,
    Screenshot = 13,
    FunctionalImageDownload = 14,
    Other = 15,
};

enum class LossKind : std::uint16_t {
    RingFull = 0,
    UnregisteredFaultProducer = 1,
    ThreadSlotExhausted = 2,
    GpuQueryExhausted = 3,
    GpuTimestampBudget = 4,
    GpuQueryReadError = 5,
    ActiveGpuRegionExhausted = 6,
    RecorderOutputError = 7,
    GpuQueryUnresolvedOnShutdown = 8,
    Count = 9,
};

struct Event64 {
    std::uint64_t qpc;
    std::uint64_t op_id;
    std::uint64_t parent_id;
    std::uint64_t arg0;
    std::uint64_t arg1;
    std::uint64_t arg2;
    std::uint32_t thread_id;
    std::uint32_t frame_hint;
    std::uint16_t event_id;
    std::uint16_t site_id;
    std::uint16_t flags;
    std::uint16_t payload_kind;
};
static_assert(sizeof(Event64) == 64);
static_assert(alignof(Event64) >= alignof(std::uint64_t));

struct ChunkHeader {
    std::uint64_t magic;
    std::uint16_t schema_major;
    std::uint16_t schema_minor;
    std::uint32_t header_bytes;
    std::uint64_t capture_id;
    std::uint64_t chunk_seq;
    std::uint32_t record_count;
    std::uint32_t payload_bytes;
    std::uint64_t qpc_first;
    std::uint64_t qpc_last;
    std::uint32_t crc32c;
    std::uint32_t reserved;
};
static_assert(sizeof(ChunkHeader) == 64);

struct ChunkTrailer {
    std::uint64_t magic;
    std::uint32_t crc32c;
    std::uint32_t payload_bytes;
};
static_assert(sizeof(ChunkTrailer) == 16);

} // namespace Common::Blackbox
