// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

#include "common/bb_blackbox/schema.h"
#include "common/bb_blackbox/sites.h"

namespace Common::Blackbox {

class Recorder {
public:
    static Recorder& Instance() noexcept;

    bool Enabled() noexcept;
    bool InitializeFromEnvironment() noexcept;
    void ShutdownProducer() noexcept;

    std::uint64_t Emit(EventId event_id, Site site, EventFlags flags = EventFlags::None,
                       PayloadKind payload = PayloadKind::None, std::uint64_t arg0 = 0,
                       std::uint64_t arg1 = 0, std::uint64_t arg2 = 0) noexcept;

    std::uint64_t EmitWithContext(EventId event_id, Site site, EventFlags flags,
                                  PayloadKind payload, std::uint64_t parent_id,
                                  std::uint32_t frame_hint, std::uint64_t arg0 = 0,
                                  std::uint64_t arg1 = 0, std::uint64_t arg2 = 0) noexcept;

    // Fault/exception producer path. This never initializes/registers the thread.
    bool TryEmitFault(EventId event_id, Site site, std::uint64_t arg0 = 0,
                      std::uint64_t arg1 = 0, std::uint64_t arg2 = 0) noexcept;

    void CountLoss(LossKind kind, std::uint64_t count = 1) noexcept;

    std::uint32_t NextGuestFrame() noexcept;
    std::uint32_t CurrentFrameHint() const noexcept;
    std::uint64_t CurrentParentId() const noexcept;
    std::uint64_t QpcNow() const noexcept;
    std::uint64_t QpcFrequency() noexcept;

    void SetFrameHint(std::uint32_t frame_hint) noexcept;
    void SetParentId(std::uint64_t parent_id) noexcept;

private:
    Recorder() noexcept = default;
    ~Recorder();

    struct Impl;
    Impl* impl_{};
};

class ScopedFrameHint {
public:
    explicit ScopedFrameHint(std::uint32_t frame_hint) noexcept;
    ~ScopedFrameHint();
    ScopedFrameHint(const ScopedFrameHint&) = delete;
    ScopedFrameHint& operator=(const ScopedFrameHint&) = delete;
private:
    std::uint32_t previous_{};
};

class ScopedEvent {
public:
    ScopedEvent(EventId event_id, Site site, PayloadKind payload = PayloadKind::DurationQpc,
                std::uint64_t arg0 = 0, std::uint64_t arg1 = 0) noexcept;
    ~ScopedEvent();
    ScopedEvent(const ScopedEvent&) = delete;
    ScopedEvent& operator=(const ScopedEvent&) = delete;

    std::uint64_t OpId() const noexcept { return op_id_; }
private:
    EventId event_id_{};
    Site site_{};
    PayloadKind payload_{};
    std::uint64_t start_qpc_{};
    std::uint64_t op_id_{};
    std::uint64_t previous_parent_{};
    std::uint64_t arg0_{};
    std::uint64_t arg1_{};
};

struct LossSnapshot {
    std::array<std::uint64_t, static_cast<std::size_t>(LossKind::Count)> counters{};
};

class Consumer {
public:
    Consumer() noexcept = default;
    ~Consumer();

    bool Open(std::string_view mapping_name) noexcept;
    std::size_t Drain(std::span<Event64> output) noexcept;
    LossSnapshot GetLossSnapshot() const noexcept;
    std::uint32_t ProducerPid() const noexcept;
    bool ProducerExitedFlag() const noexcept;
    std::uint64_t CaptureId() const noexcept;
    std::uint64_t QpcFrequency() const noexcept;

private:
    struct Impl;
    Impl* impl_{};
};

} // namespace Common::Blackbox
