// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include "common/bb_blackbox/identity.h"

#include <atomic>
#include <cstdint>
#include <string_view>

#include "common/bb_blackbox/recorder.h"

namespace Common::Blackbox {
namespace {

constexpr std::uint64_t Fnv1a64(std::string_view value) noexcept {
    std::uint64_t hash = 14695981039346656037ULL;
    for (const char c : value) {
        hash ^= static_cast<std::uint8_t>(c);
        hash *= 1099511628211ULL;
    }
    return hash;
}

constexpr std::string_view Baseline =
    "03d62ad22438344f1dcd38c5b5e44f660b564b92";
constexpr std::string_view ParentPatch =
    "92ee02584cae06cc4feace76dcbfdaadcca225e3a005b1038246850fa154c485";

} // namespace

void EmitCoreIdentityOnce() noexcept {
    static std::atomic<bool> emitted{false};
    bool expected = false;
    if (!emitted.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) {
        return;
    }

    auto& recorder = Recorder::Instance();
    if (!recorder.InitializeFromEnvironment()) {
        return;
    }

    recorder.Emit(EventId::Session, Site::Unknown, EventFlags::Success, PayloadKind::None,
                  Fnv1a64(Baseline), Fnv1a64(ParentPatch),
                  (static_cast<std::uint64_t>(SchemaMajor) << 32) | SchemaMinor);
    recorder.Emit(EventId::Capability, Site::Unknown, EventFlags::Success,
                  PayloadKind::DurationQpc, recorder.QpcFrequency(), 0, 0);
}

} // namespace Common::Blackbox
