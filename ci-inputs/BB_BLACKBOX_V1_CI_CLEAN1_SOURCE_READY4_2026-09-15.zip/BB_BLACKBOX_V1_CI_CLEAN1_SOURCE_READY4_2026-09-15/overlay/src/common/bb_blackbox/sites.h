// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include <cstdint>

namespace Common::Blackbox {

enum class Site : std::uint16_t {
    Unknown = 0,

    VideoOutSubmitFlip = 20,
    VideoOutFlip = 21,

    BufferDownloadMemory = 100,
    BufferReadEdgeImagePages = 101,
    BufferSynchronize = 102,
    BufferSynchronizeFromImage = 103,

    ImageDownload = 120,

    TileDetile = 130,
    TileRetile = 131,

    PresenterGetRenderFrame = 180,
    PresenterPresent = 181,
    PresenterHostCommands = 182,
    PresenterFreeQueueWait = 183,
    PresenterFenceWait = 184,
    PresenterAcquire = 185,
    PresenterSwapchainPresent = 186,

    SchedulerWait = 200,
    SchedulerFinish = 201,
    SchedulerFlush = 202,
    SchedulerSubmit = 203,
    SchedulerPriorityPendingWait = 204,

    GpuCommandBufferEnvelope = 220,
    GpuRegionReadback = 221,
    GpuRegionDetile = 222,
    GpuRegionRetile = 223,
    GpuRegionHostPresent = 224,
};

} // namespace Common::Blackbox
