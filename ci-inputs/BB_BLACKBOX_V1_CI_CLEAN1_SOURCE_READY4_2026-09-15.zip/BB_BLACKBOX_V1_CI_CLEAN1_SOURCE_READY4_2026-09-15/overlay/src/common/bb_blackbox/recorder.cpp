// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include "common/bb_blackbox/recorder.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <new>
#include <string>

#ifdef _WIN32
#include <Windows.h>
#else
#include <chrono>
#include <thread>
#endif

namespace Common::Blackbox {
namespace {

// The Windows recorder maps these atomics into shared memory across processes.
// CLEAN1 is fail-closed: do not silently fall back to library locks that are not
// process-shared. The Tier-B target is x86-64 clang-cl/MSVC STL.
static_assert(std::atomic<std::uint32_t>::is_always_lock_free,
              "BLACKBOX requires lock-free 32-bit shared-memory atomics");
static_assert(std::atomic<std::uint64_t>::is_always_lock_free,
              "BLACKBOX requires lock-free 64-bit shared-memory atomics");

struct alignas(64) SharedSlot {
    std::atomic<std::uint32_t> state{0}; // 0 free, 1 producer-owned
    std::uint32_t thread_id{};
    std::uint32_t slot_index{};
    std::uint32_t reserved0{};
    alignas(64) std::atomic<std::uint64_t> published{0};
    alignas(64) std::atomic<std::uint64_t> consumed{0};
    alignas(64) std::atomic<std::uint64_t> lost{0};
    alignas(64) std::array<Event64, EventsPerThread> events{};
};

struct alignas(64) SharedState {
    std::uint64_t magic{};
    std::uint32_t schema_major{};
    std::uint32_t schema_minor{};
    std::uint64_t capture_id{};
    std::uint64_t qpc_frequency{};
    std::atomic<std::uint32_t> producer_pid{0};
    std::atomic<std::uint32_t> producer_exited{0};
    std::atomic<std::uint32_t> guest_frame_seq{0};
    std::uint32_t reserved0{};
    alignas(64) std::array<std::atomic<std::uint64_t>,
                           static_cast<std::size_t>(LossKind::Count)> loss{};
    alignas(64) std::array<SharedSlot, ThreadSlotCount> slots{};
};

struct TlsContext {
    SharedSlot* slot{};
    std::uint64_t local_op_seq{};
    std::uint64_t parent_id{};
    std::uint32_t frame_hint{};
    bool registering{};
};
thread_local TlsContext tls{};

std::uint64_t LocalQpc() noexcept {
#ifdef _WIN32
    LARGE_INTEGER value{};
    QueryPerformanceCounter(&value);
    return static_cast<std::uint64_t>(value.QuadPart);
#else
    return static_cast<std::uint64_t>(
        std::chrono::steady_clock::now().time_since_epoch().count());
#endif
}

std::uint64_t LocalQpcFrequency() noexcept {
#ifdef _WIN32
    LARGE_INTEGER value{};
    QueryPerformanceFrequency(&value);
    return static_cast<std::uint64_t>(value.QuadPart);
#else
    using P = std::chrono::steady_clock::period;
    return static_cast<std::uint64_t>(P::den / P::num);
#endif
}

std::uint32_t LocalThreadId() noexcept {
#ifdef _WIN32
    return static_cast<std::uint32_t>(GetCurrentThreadId());
#else
    return static_cast<std::uint32_t>(
        std::hash<std::thread::id>{}(std::this_thread::get_id()));
#endif
}

std::uint32_t LocalProcessId() noexcept {
#ifdef _WIN32
    return static_cast<std::uint32_t>(GetCurrentProcessId());
#else
    return 1;
#endif
}

[[maybe_unused]] std::uint64_t MakeCaptureId() noexcept {
    const std::uint64_t qpc = LocalQpc();
    const std::uint64_t pid = LocalProcessId();
    return (qpc << 17) ^ (qpc >> 13) ^ (pid * 0x9E3779B185EBCA87ULL);
}

} // namespace

struct Recorder::Impl {
#ifdef _WIN32
    HANDLE mapping{};
#endif
    SharedState* shared{};
    std::atomic<bool> init_attempted{false};

    bool EnsureMapped() noexcept {
        if (shared != nullptr) {
            return true;
        }
        bool expected = false;
        if (!init_attempted.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) {
            return shared != nullptr;
        }

        const char* env_name = std::getenv("BB_BLACKBOX_MAPPING");
        if (env_name == nullptr || env_name[0] == '\0') {
            return false;
        }

#ifdef _WIN32
        std::wstring mapping_name;
        while (*env_name) {
            mapping_name.push_back(static_cast<unsigned char>(*env_name++));
        }
        mapping = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0,
                                     static_cast<DWORD>(sizeof(SharedState)), mapping_name.c_str());
        if (mapping == nullptr) {
            return false;
        }
        const bool already_exists = GetLastError() == ERROR_ALREADY_EXISTS;
        auto* view = MapViewOfFile(mapping, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedState));
        if (view == nullptr) {
            CloseHandle(mapping);
            mapping = nullptr;
            return false;
        }
        shared = static_cast<SharedState*>(view);
        if (!already_exists) {
            std::construct_at(shared);
            shared->magic = SharedMagic;
            shared->schema_major = SchemaMajor;
            shared->schema_minor = SchemaMinor;
            shared->capture_id = MakeCaptureId();
            shared->qpc_frequency = LocalQpcFrequency();
            for (std::uint32_t i = 0; i < ThreadSlotCount; ++i) {
                shared->slots[i].slot_index = i;
            }
        } else if (shared->magic != SharedMagic || shared->schema_major != SchemaMajor) {
            UnmapViewOfFile(shared);
            CloseHandle(mapping);
            shared = nullptr;
            mapping = nullptr;
            return false;
        }
#else
        // Runtime target is Windows. Non-Windows build keeps Blackbox disabled.
        return false;
#endif

        shared->producer_pid.store(LocalProcessId(), std::memory_order_release);
        shared->producer_exited.store(0, std::memory_order_release);
        return true;
    }

    SharedSlot* RegisterThread() noexcept {
        if (tls.slot != nullptr) {
            return tls.slot;
        }
        if (tls.registering || !EnsureMapped()) {
            return nullptr;
        }
        tls.registering = true;
        for (std::uint32_t i = 0; i < ThreadSlotCount; ++i) {
            auto& candidate = shared->slots[i];
            std::uint32_t expected = 0;
            if (candidate.state.compare_exchange_strong(expected, 1, std::memory_order_acq_rel)) {
                candidate.thread_id = LocalThreadId();
                candidate.published.store(0, std::memory_order_relaxed);
                candidate.consumed.store(0, std::memory_order_relaxed);
                candidate.lost.store(0, std::memory_order_relaxed);
                tls.slot = &candidate;
                tls.local_op_seq = 0;
                tls.registering = false;
                return tls.slot;
            }
        }
        tls.registering = false;
        shared->loss[static_cast<std::size_t>(LossKind::ThreadSlotExhausted)]
            .fetch_add(1, std::memory_order_relaxed);
        return nullptr;
    }

    std::uint64_t EmitInternal(EventId event_id, Site site, EventFlags flags, PayloadKind payload,
                               std::uint64_t parent_id, std::uint32_t frame_hint,
                               std::uint64_t arg0, std::uint64_t arg1, std::uint64_t arg2,
                               bool allow_register) noexcept {
        SharedSlot* slot = tls.slot;
        if (slot == nullptr && allow_register) {
            slot = RegisterThread();
        }
        if (slot == nullptr) {
            if (shared != nullptr) {
                shared->loss[static_cast<std::size_t>(LossKind::UnregisteredFaultProducer)]
                    .fetch_add(1, std::memory_order_relaxed);
            }
            return 0;
        }

        const std::uint64_t write = slot->published.load(std::memory_order_relaxed);
        const std::uint64_t read = slot->consumed.load(std::memory_order_acquire);
        if (write - read >= EventsPerThread) {
            slot->lost.fetch_add(1, std::memory_order_relaxed);
            shared->loss[static_cast<std::size_t>(LossKind::RingFull)]
                .fetch_add(1, std::memory_order_relaxed);
            return 0;
        }

        const std::uint64_t local = ++tls.local_op_seq;
        const std::uint64_t op_id =
            (static_cast<std::uint64_t>(slot->slot_index + 1) << 56) |
            (local & 0x00FFFFFFFFFFFFFFULL);

        Event64 ev{
            .qpc = LocalQpc(),
            .op_id = op_id,
            .parent_id = parent_id,
            .arg0 = arg0,
            .arg1 = arg1,
            .arg2 = arg2,
            .thread_id = slot->thread_id,
            .frame_hint = frame_hint,
            .event_id = static_cast<std::uint16_t>(event_id),
            .site_id = static_cast<std::uint16_t>(site),
            .flags = static_cast<std::uint16_t>(flags),
            .payload_kind = static_cast<std::uint16_t>(payload),
        };
        slot->events[write % EventsPerThread] = ev;
        std::atomic_thread_fence(std::memory_order_release);
        slot->published.store(write + 1, std::memory_order_release);
        return op_id;
    }
};

Recorder& Recorder::Instance() noexcept {
    // Construct Impl first so Recorder is destroyed first and can still mark producer_exited.
    static Impl impl;
    static Recorder recorder;
    recorder.impl_ = &impl;
    return recorder;
}

Recorder::~Recorder() {
    ShutdownProducer();
}

bool Recorder::Enabled() noexcept {
    return impl_ != nullptr && impl_->EnsureMapped();
}

bool Recorder::InitializeFromEnvironment() noexcept {
    return impl_ != nullptr && impl_->EnsureMapped();
}

void Recorder::ShutdownProducer() noexcept {
    if (impl_ == nullptr || impl_->shared == nullptr) {
        return;
    }
    impl_->shared->producer_exited.store(1, std::memory_order_release);
#ifdef _WIN32
    UnmapViewOfFile(impl_->shared);
    impl_->shared = nullptr;
    if (impl_->mapping != nullptr) {
        CloseHandle(impl_->mapping);
        impl_->mapping = nullptr;
    }
#endif
}

std::uint64_t Recorder::Emit(EventId event_id, Site site, EventFlags flags, PayloadKind payload,
                             std::uint64_t arg0, std::uint64_t arg1,
                             std::uint64_t arg2) noexcept {
    if (impl_ == nullptr) {
        (void)Instance();
    }
    return impl_->EmitInternal(event_id, site, flags, payload, tls.parent_id, tls.frame_hint,
                               arg0, arg1, arg2, true);
}

std::uint64_t Recorder::EmitWithContext(EventId event_id, Site site, EventFlags flags,
                                        PayloadKind payload, std::uint64_t parent_id,
                                        std::uint32_t frame_hint, std::uint64_t arg0,
                                        std::uint64_t arg1, std::uint64_t arg2) noexcept {
    if (impl_ == nullptr) {
        (void)Instance();
    }
    return impl_->EmitInternal(event_id, site, flags, payload, parent_id, frame_hint,
                               arg0, arg1, arg2, true);
}

bool Recorder::TryEmitFault(EventId event_id, Site site, std::uint64_t arg0,
                            std::uint64_t arg1, std::uint64_t arg2) noexcept {
    if (impl_ == nullptr || impl_->shared == nullptr || tls.slot == nullptr) {
        if (impl_ != nullptr && impl_->shared != nullptr) {
            CountLoss(LossKind::UnregisteredFaultProducer);
        }
        return false;
    }
    return impl_->EmitInternal(event_id, site, EventFlags::None, PayloadKind::None,
                               tls.parent_id, tls.frame_hint, arg0, arg1, arg2, false) != 0;
}

void Recorder::CountLoss(LossKind kind, std::uint64_t count) noexcept {
    if (impl_ == nullptr || impl_->shared == nullptr) {
        return;
    }
    const auto index = static_cast<std::size_t>(kind);
    if (index < static_cast<std::size_t>(LossKind::Count)) {
        impl_->shared->loss[index].fetch_add(count, std::memory_order_relaxed);
    }
}

std::uint32_t Recorder::NextGuestFrame() noexcept {
    if (impl_ == nullptr) {
        (void)Instance();
    }
    if (impl_->EnsureMapped()) {
        return impl_->shared->guest_frame_seq.fetch_add(1, std::memory_order_relaxed) + 1;
    }
    static std::atomic<std::uint32_t> local_frame{0};
    return local_frame.fetch_add(1, std::memory_order_relaxed) + 1;
}

std::uint32_t Recorder::CurrentFrameHint() const noexcept {
    return tls.frame_hint;
}

std::uint64_t Recorder::CurrentParentId() const noexcept {
    return tls.parent_id;
}

std::uint64_t Recorder::QpcNow() const noexcept {
    return LocalQpc();
}

std::uint64_t Recorder::QpcFrequency() noexcept {
    if (impl_ != nullptr && impl_->EnsureMapped()) {
        return impl_->shared->qpc_frequency;
    }
    return LocalQpcFrequency();
}

void Recorder::SetFrameHint(std::uint32_t frame_hint) noexcept {
    tls.frame_hint = frame_hint;
}

void Recorder::SetParentId(std::uint64_t parent_id) noexcept {
    tls.parent_id = parent_id;
}

ScopedFrameHint::ScopedFrameHint(std::uint32_t frame_hint) noexcept {
    auto& recorder = Recorder::Instance();
    previous_ = recorder.CurrentFrameHint();
    recorder.SetFrameHint(frame_hint);
}

ScopedFrameHint::~ScopedFrameHint() {
    Recorder::Instance().SetFrameHint(previous_);
}

ScopedEvent::ScopedEvent(EventId event_id, Site site, PayloadKind payload,
                         std::uint64_t arg0, std::uint64_t arg1) noexcept
    : event_id_{event_id}, site_{site}, payload_{payload}, arg0_{arg0}, arg1_{arg1} {
    auto& recorder = Recorder::Instance();
    previous_parent_ = recorder.CurrentParentId();
    start_qpc_ = recorder.QpcNow();
    op_id_ = recorder.Emit(event_id_, site_, EventFlags::Begin, payload_, arg0_, arg1_, 0);
    if (op_id_ != 0) {
        recorder.SetParentId(op_id_);
    }
}

ScopedEvent::~ScopedEvent() {
    auto& recorder = Recorder::Instance();
    const std::uint64_t duration = recorder.QpcNow() - start_qpc_;
    recorder.SetParentId(previous_parent_);
    // If BEGIN could not be recorded (for example ring/registration pressure),
    // emitting END would fabricate an orphan scope with parent_id=0. Fail closed.
    if (op_id_ != 0) {
        recorder.EmitWithContext(event_id_, site_, EventFlags::End, payload_,
                                 op_id_, recorder.CurrentFrameHint(), arg0_, arg1_, duration);
    }
}

struct Consumer::Impl {
#ifdef _WIN32
    HANDLE mapping{};
#endif
    SharedState* shared{};
    std::uint32_t next_slot{};
};

Consumer::~Consumer() {
#ifdef _WIN32
    if (impl_ != nullptr && impl_->shared != nullptr) {
        UnmapViewOfFile(impl_->shared);
    }
    if (impl_ != nullptr && impl_->mapping != nullptr) {
        CloseHandle(impl_->mapping);
    }
#endif
    delete impl_;
    impl_ = nullptr;
}

bool Consumer::Open(std::string_view mapping_name) noexcept {
    if (impl_ == nullptr) {
        impl_ = new (std::nothrow) Impl{};
        if (impl_ == nullptr) {
            return false;
        }
    }
#ifdef _WIN32
    std::wstring wide;
    wide.reserve(mapping_name.size());
    for (const char c : mapping_name) {
        wide.push_back(static_cast<unsigned char>(c));
    }
    impl_->mapping = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0,
                                        static_cast<DWORD>(sizeof(SharedState)), wide.c_str());
    if (impl_->mapping == nullptr) {
        return false;
    }
    const bool already_exists = GetLastError() == ERROR_ALREADY_EXISTS;
    auto* view = MapViewOfFile(impl_->mapping, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedState));
    if (view == nullptr) {
        CloseHandle(impl_->mapping);
        impl_->mapping = nullptr;
        return false;
    }
    impl_->shared = static_cast<SharedState*>(view);
    if (!already_exists) {
        std::construct_at(impl_->shared);
        impl_->shared->magic = SharedMagic;
        impl_->shared->schema_major = SchemaMajor;
        impl_->shared->schema_minor = SchemaMinor;
        impl_->shared->capture_id = MakeCaptureId();
        impl_->shared->qpc_frequency = LocalQpcFrequency();
        for (std::uint32_t i = 0; i < ThreadSlotCount; ++i) {
            impl_->shared->slots[i].slot_index = i;
        }
    }
    return impl_->shared->magic == SharedMagic && impl_->shared->schema_major == SchemaMajor;
#else
    (void)mapping_name;
    return false;
#endif
}

std::size_t Consumer::Drain(std::span<Event64> output) noexcept {
    if (impl_ == nullptr || impl_->shared == nullptr || output.empty()) {
        return 0;
    }
    std::size_t count = 0;
    for (std::uint32_t pass = 0; pass < ThreadSlotCount && count < output.size(); ++pass) {
        const std::uint32_t slot_index = (impl_->next_slot + pass) % ThreadSlotCount;
        auto& slot = impl_->shared->slots[slot_index];
        if (slot.state.load(std::memory_order_acquire) == 0) {
            continue;
        }
        std::uint64_t read = slot.consumed.load(std::memory_order_relaxed);
        const std::uint64_t write = slot.published.load(std::memory_order_acquire);
        while (read < write && count < output.size()) {
            output[count++] = slot.events[read % EventsPerThread];
            ++read;
        }
        slot.consumed.store(read, std::memory_order_release);
    }
    impl_->next_slot = (impl_->next_slot + 1) % ThreadSlotCount;
    return count;
}

LossSnapshot Consumer::GetLossSnapshot() const noexcept {
    LossSnapshot out{};
    if (impl_ == nullptr || impl_->shared == nullptr) {
        return out;
    }
    for (std::size_t i = 0; i < out.counters.size(); ++i) {
        out.counters[i] = impl_->shared->loss[i].load(std::memory_order_relaxed);
    }
    return out;
}

std::uint32_t Consumer::ProducerPid() const noexcept {
    if (impl_ == nullptr || impl_->shared == nullptr) {
        return 0;
    }
    return impl_->shared->producer_pid.load(std::memory_order_acquire);
}

bool Consumer::ProducerExitedFlag() const noexcept {
    if (impl_ == nullptr || impl_->shared == nullptr) {
        return false;
    }
    return impl_->shared->producer_exited.load(std::memory_order_acquire) != 0;
}

std::uint64_t Consumer::CaptureId() const noexcept {
    return impl_ && impl_->shared ? impl_->shared->capture_id : 0;
}

std::uint64_t Consumer::QpcFrequency() const noexcept {
    return impl_ && impl_->shared ? impl_->shared->qpc_frequency : 0;
}

} // namespace Common::Blackbox
