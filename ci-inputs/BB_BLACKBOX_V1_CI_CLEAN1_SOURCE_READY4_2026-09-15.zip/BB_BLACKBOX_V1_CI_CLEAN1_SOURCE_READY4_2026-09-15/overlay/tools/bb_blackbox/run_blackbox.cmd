@echo off
setlocal EnableExtensions

if "%~1"=="" (
  echo Usage: run_blackbox.cmd ^<path-to-shadPS4.exe^>
  exit /b 2
)

set "SHAD=%~1"
if not "%~2"=="" (
  echo CLEAN1 launcher currently accepts only the shadPS4.exe path.
  exit /b 5
)

for %%I in ("%~dp0..\..\bb_blackbox_recorder.exe") do set "REC=%%~fI"
if not exist "%REC%" (
  echo bb_blackbox_recorder.exe not found next to the packaged tools.
  exit /b 3
)

set "STAMP=%RANDOM%%RANDOM%%RANDOM%"
set "BB_BLACKBOX_MAPPING=Local\BB_BLACKBOX_%STAMP%"
set "OUTDIR=%CD%\BB_BLACKBOX_%STAMP%"

if not exist "%OUTDIR%" mkdir "%OUTDIR%"
if errorlevel 1 (
  echo Failed to create capture directory: "%OUTDIR%"
  exit /b 4
)

start "BB Blackbox Recorder" /b "%REC%" "%BB_BLACKBOX_MAPPING%" "%OUTDIR%"
timeout /t 1 /nobreak >nul

"%SHAD%"
set "GAME_RC=%ERRORLEVEL%"

echo Capture directory: "%OUTDIR%"
exit /b %GAME_RC%
