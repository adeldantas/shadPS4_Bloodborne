// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include <array>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <span>
#include <sstream>
#include <string>
#include <system_error>
#include <thread>
#include <vector>

#ifdef _WIN32
#include <Windows.h>
#endif

#include "common/bb_blackbox/recorder.h"
#include "common/bb_blackbox/schema.h"

namespace BB = Common::Blackbox;
namespace FS = std::filesystem;

namespace {

constexpr std::uint64_t MiB = 1024ULL * 1024ULL;
constexpr std::uint64_t SegmentBytes = 32ULL * MiB;
constexpr std::uint32_t SegmentSlots = 16;
constexpr std::uint64_t RawEventCapBytes = SegmentBytes * SegmentSlots;
constexpr auto StatusPeriod = std::chrono::seconds(2);
constexpr auto ProducerStartTimeout = std::chrono::seconds(30);

std::uint32_t Crc32c(std::span<const std::byte> data) {
    std::uint32_t crc = 0xFFFFFFFFu;
    for (const std::byte value : data) {
        crc ^= static_cast<std::uint8_t>(value);
        for (int bit = 0; bit < 8; ++bit) {
            const std::uint32_t mask = -(crc & 1u);
            crc = (crc >> 1) ^ (0x82F63B78u & mask);
        }
    }
    return ~crc;
}

std::uint64_t ChunkBytes(std::size_t event_count) {
    return sizeof(BB::ChunkHeader) + event_count * sizeof(BB::Event64) +
           sizeof(BB::ChunkTrailer);
}

bool WriteChunk(std::ofstream& out, std::span<const BB::Event64> events,
                std::uint64_t capture_id, std::uint64_t seq) {
    if (events.empty()) {
        return true;
    }

    BB::ChunkHeader header{
        .magic = BB::ChunkMagic,
        .schema_major = static_cast<std::uint16_t>(BB::SchemaMajor),
        .schema_minor = static_cast<std::uint16_t>(BB::SchemaMinor),
        .header_bytes = sizeof(BB::ChunkHeader),
        .capture_id = capture_id,
        .chunk_seq = seq,
        .record_count = static_cast<std::uint32_t>(events.size()),
        .payload_bytes = static_cast<std::uint32_t>(events.size_bytes()),
        .qpc_first = events.front().qpc,
        .qpc_last = events.back().qpc,
        .crc32c = 0,
        .reserved = 0,
    };

    std::vector<std::byte> crc_input(sizeof(header) + events.size_bytes());
    std::memcpy(crc_input.data(), &header, sizeof(header));
    std::memcpy(crc_input.data() + sizeof(header), events.data(), events.size_bytes());
    header.crc32c = Crc32c(crc_input);

    const BB::ChunkTrailer trailer{
        .magic = BB::TrailerMagic,
        .crc32c = header.crc32c,
        .payload_bytes = header.payload_bytes,
    };

    out.write(reinterpret_cast<const char*>(&header), sizeof(header));
    out.write(reinterpret_cast<const char*>(events.data()),
              static_cast<std::streamsize>(events.size_bytes()));
    out.write(reinterpret_cast<const char*>(&trailer), sizeof(trailer));
    return static_cast<bool>(out);
}

std::string SegmentName(std::uint32_t slot) {
    std::ostringstream name;
    name << "events_" << std::setw(3) << std::setfill('0') << slot << ".bbx";
    return name.str();
}

class SegmentedWriter {
public:
    explicit SegmentedWriter(FS::path capture_dir) : capture_dir_{std::move(capture_dir)} {}

    bool Open() {
        std::error_code ec;
        FS::create_directories(capture_dir_, ec);
        if (ec) {
            return false;
        }
        return OpenSlot(0);
    }

    bool Write(std::span<const BB::Event64> events, std::uint64_t capture_id,
               std::uint64_t seq) {
        const std::uint64_t bytes = ChunkBytes(events.size());
        if (bytes > SegmentBytes) {
            return false;
        }
        if (slot_bytes_ != 0 && slot_bytes_ + bytes > SegmentBytes) {
            if (!Rotate()) {
                return false;
            }
        }
        if (!WriteChunk(out_, events, capture_id, seq)) {
            return false;
        }
        slot_bytes_ += bytes;
        total_written_bytes_ += bytes;
        return true;
    }

    void Flush() {
        if (out_) {
            out_.flush();
        }
    }

    const FS::path& CaptureDir() const noexcept {
        return capture_dir_;
    }

    std::uint32_t CurrentSlot() const noexcept {
        return current_slot_;
    }

    std::uint64_t CurrentSlotBytes() const noexcept {
        return slot_bytes_;
    }

    std::uint64_t RotationCount() const noexcept {
        return rotation_count_;
    }

    std::uint64_t OverwriteCount() const noexcept {
        return overwrite_count_;
    }

    std::uint64_t TotalWrittenBytes() const noexcept {
        return total_written_bytes_;
    }

private:
    bool Rotate() {
        Flush();
        out_.close();

        const std::uint32_t next =
            current_slot_ == 0 ? 1 : (current_slot_ == SegmentSlots - 1 ? 1 : current_slot_ + 1);
        ++rotation_count_;
        return OpenSlot(next);
    }

    bool OpenSlot(std::uint32_t slot) {
        if (slot >= SegmentSlots) {
            return false;
        }
        if (used_[slot]) {
            ++overwrite_count_;
        }
        used_[slot] = true;
        current_slot_ = slot;
        slot_bytes_ = 0;

        out_.open(capture_dir_ / SegmentName(slot),
                  std::ios::binary | std::ios::trunc);
        return static_cast<bool>(out_);
    }

private:
    FS::path capture_dir_;
    std::ofstream out_;
    std::array<bool, SegmentSlots> used_{};
    std::uint32_t current_slot_{};
    std::uint64_t slot_bytes_{};
    std::uint64_t rotation_count_{};
    std::uint64_t overwrite_count_{};
    std::uint64_t total_written_bytes_{};
};

std::uint64_t LossTotal(const BB::LossSnapshot& loss) {
    std::uint64_t total = 0;
    for (const auto value : loss.counters) {
        total += value;
    }
    return total;
}

bool ReplaceFileAtomically(const FS::path& temp, const FS::path& target) {
#ifdef _WIN32
    return MoveFileExW(temp.c_str(), target.c_str(),
                       MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
#else
    std::error_code ec;
    FS::rename(temp, target, ec);
    return !ec;
#endif
}

bool WriteStatus(const SegmentedWriter& writer, bool complete, bool producer_seen,
                 bool producer_exited, std::uint64_t capture_id,
                 std::uint64_t qpc_frequency, std::uint64_t next_chunk_seq,
                 const BB::LossSnapshot& loss, const char* terminal_reason) {
    const FS::path target = writer.CaptureDir() / "capture_status.json";
    const FS::path temp = writer.CaptureDir() / "capture_status.json.tmp";

    std::ofstream out(temp, std::ios::binary | std::ios::trunc);
    if (!out) {
        return false;
    }

    out << "{\n"
        << "  \"schema_major\": " << BB::SchemaMajor << ",\n"
        << "  \"schema_minor\": " << BB::SchemaMinor << ",\n"
        << "  \"complete\": " << (complete ? "true" : "false") << ",\n"
        << "  \"capture_id\": " << capture_id << ",\n"
        << "  \"qpc_frequency\": " << qpc_frequency << ",\n"
        << "  \"producer_seen\": " << (producer_seen ? "true" : "false") << ",\n"
        << "  \"producer_exited\": " << (producer_exited ? "true" : "false") << ",\n"
        << "  \"segment_slots\": " << SegmentSlots << ",\n"
        << "  \"segment_bytes\": " << SegmentBytes << ",\n"
        << "  \"raw_event_cap_bytes\": " << RawEventCapBytes << ",\n"
        << "  \"startup_segment_pinned\": true,\n"
        << "  \"current_segment_slot\": " << writer.CurrentSlot() << ",\n"
        << "  \"current_segment_bytes\": " << writer.CurrentSlotBytes() << ",\n"
        << "  \"rotation_count\": " << writer.RotationCount() << ",\n"
        << "  \"retention_overwrite_count\": " << writer.OverwriteCount() << ",\n"
        << "  \"total_event_bytes_written\": " << writer.TotalWrittenBytes() << ",\n"
        << "  \"next_chunk_seq\": " << next_chunk_seq << ",\n"
        << "  \"event_loss_total\": " << LossTotal(loss) << ",\n"
        << "  \"trigger_snapshot_retention\": \"PARTIAL_NOT_IMPLEMENTED\",\n"
        << "  \"terminal_reason\": \"" << terminal_reason << "\"\n"
        << "}\n";
    out.flush();
    if (!out) {
        return false;
    }
    out.close();
    return ReplaceFileAtomically(temp, target);
}

} // namespace

int main(int argc, char** argv) {
    if (argc < 3) {
        std::fprintf(stderr,
                     "usage: bb_blackbox_recorder <mapping-name> <capture-directory>\n");
        return 2;
    }

    const std::string mapping = argv[1];
    const FS::path capture_dir = argv[2];

    BB::Consumer consumer;
    if (!consumer.Open(mapping)) {
        std::fprintf(stderr, "failed to create/open Blackbox mapping\n");
        return 3;
    }

    SegmentedWriter writer{capture_dir};
    if (!writer.Open()) {
        std::fprintf(stderr, "failed to create capture directory/segment\n");
        return 4;
    }

    std::array<BB::Event64, BB::MaxChunkEvents> buffer{};
    std::uint64_t chunk_seq = 0;
    std::uint32_t producer_pid = 0;

#ifdef _WIN32
    HANDLE producer_process = nullptr;
#endif

    BB::LossSnapshot previous_loss{};
    bool producer_seen = false;
    bool producer_exited = false;
    auto start_time = std::chrono::steady_clock::now();
    auto last_status = start_time;

    if (!WriteStatus(writer, false, false, false, consumer.CaptureId(),
                     consumer.QpcFrequency(), chunk_seq, previous_loss, "running")) {
        std::fprintf(stderr, "failed to write initial capture_status.json\n");
        return 5;
    }

    auto write_events = [&](std::span<const BB::Event64> events) -> bool {
        if (events.empty()) {
            return true;
        }
        if (!writer.Write(events, consumer.CaptureId(), chunk_seq++)) {
            return false;
        }
        return true;
    };

    int result = 0;
    const char* terminal_reason = "normal_exit";

    for (;;) {
        const std::size_t count = consumer.Drain(buffer);
        if (count != 0 && !write_events(std::span{buffer.data(), count})) {
            result = 6;
            terminal_reason = "event_segment_write_error";
            break;
        }

        if (!producer_seen) {
            producer_pid = consumer.ProducerPid();
            if (producer_pid != 0) {
                producer_seen = true;
#ifdef _WIN32
                producer_process = OpenProcess(SYNCHRONIZE, FALSE, producer_pid);
#endif
            } else if (std::chrono::steady_clock::now() - start_time > ProducerStartTimeout) {
                result = 7;
                terminal_reason = "producer_start_timeout";
                break;
            }
        }

        const auto loss = consumer.GetLossSnapshot();
        std::array<BB::Event64, static_cast<std::size_t>(BB::LossKind::Count)> loss_events{};
        std::size_t loss_count = 0;
        for (std::size_t i = 0; i < loss.counters.size(); ++i) {
            if (loss.counters[i] != previous_loss.counters[i]) {
                const auto delta = loss.counters[i] - previous_loss.counters[i];
                loss_events[loss_count++] = BB::Event64{
                    .qpc = 0,
                    .op_id = 0,
                    .parent_id = 0,
                    .arg0 = delta,
                    .arg1 = static_cast<std::uint64_t>(i),
                    .arg2 = loss.counters[i],
                    .thread_id = 0,
                    .frame_hint = 0,
                    .event_id = static_cast<std::uint16_t>(BB::EventId::Loss),
                    .site_id = static_cast<std::uint16_t>(BB::Site::Unknown),
                    .flags = static_cast<std::uint16_t>(BB::EventFlags::Unknown),
                    .payload_kind = static_cast<std::uint16_t>(BB::PayloadKind::Loss),
                };
            }
        }
        previous_loss = loss;
        if (loss_count != 0 &&
            !write_events(std::span{loss_events.data(), loss_count})) {
            result = 8;
            terminal_reason = "loss_segment_write_error";
            break;
        }

        producer_exited = consumer.ProducerExitedFlag();
#ifdef _WIN32
        if (!producer_exited && producer_process != nullptr &&
            WaitForSingleObject(producer_process, 0) == WAIT_OBJECT_0) {
            producer_exited = true;
        }
#endif

        if (producer_seen && producer_exited) {
            // Drain twice after exit to consume all release-published records.
            for (int pass = 0; pass < 2; ++pass) {
                const std::size_t tail = consumer.Drain(buffer);
                if (tail != 0 && !write_events(std::span{buffer.data(), tail})) {
                    result = 9;
                    terminal_reason = "tail_segment_write_error";
                    break;
                }
            }
            break;
        }

        const auto now = std::chrono::steady_clock::now();
        if (now - last_status >= StatusPeriod) {
            writer.Flush();
            if (!WriteStatus(writer, false, producer_seen, producer_exited,
                             consumer.CaptureId(), consumer.QpcFrequency(), chunk_seq,
                             previous_loss, "running")) {
                result = 10;
                terminal_reason = "status_write_error";
                break;
            }
            last_status = now;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }

    writer.Flush();
    const auto final_loss = consumer.GetLossSnapshot();
    const bool complete = result == 0 && producer_seen && producer_exited;
    if (!WriteStatus(writer, complete, producer_seen, producer_exited,
                     consumer.CaptureId(), consumer.QpcFrequency(), chunk_seq,
                     final_loss, terminal_reason) && result == 0) {
        result = 11;
    }

#ifdef _WIN32
    if (producer_process != nullptr) {
        CloseHandle(producer_process);
    }
#endif
    return result;
}
