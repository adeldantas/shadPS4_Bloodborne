#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import struct
import tempfile
from pathlib import Path

EVENT = struct.Struct("<QQQQQQIIHHHH")
CHUNK = struct.Struct("<QHHIQQIIQQII")
TRAILER = struct.Struct("<QII")
assert EVENT.size == 64
assert CHUNK.size == 64
assert TRAILER.size == 16

CHUNK_MAGIC = 0x314B4E4843584242
TRAILER_MAGIC = 0x31524C5254584242

EV_CAPABILITY = 3
EV_FRAME_SUBMIT = 10
EV_FRAME_PRESENT = 12
EV_SUBMIT = 33
EV_READBACK_REQUEST = 50
EV_READBACK_COPY = 51
EV_BACKING_COMMIT = 52
EV_GPU_REGION = 70
EV_GPU_QUERY_RESULT = 71
EV_LOSS = 250
EV_HEARTBEAT = 251

FLAG_SUCCESS = 1 << 2
FLAG_AVAILABLE = 1 << 3
FLAG_REUSED = 1 << 9


def crc32c(data: bytes) -> int:
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0x82F63B78 & (-(crc & 1) & 0xFFFFFFFF))
    return (~crc) & 0xFFFFFFFF


def parse_event(data: bytes):
    keys = ("qpc", "op_id", "parent_id", "arg0", "arg1", "arg2", "thread_id",
            "frame_hint", "event_id", "site_id", "flags", "payload_kind")
    return dict(zip(keys, EVENT.unpack(data)))


def scan_chunks(path: Path):
    raw = path.read_bytes()
    off = 0
    chunks = []
    stop_reason = "clean_eof"

    while off < len(raw):
        if off + CHUNK.size > len(raw):
            stop_reason = "truncated_header"
            break

        h = CHUNK.unpack_from(raw, off)
        (magic, major, minor, header_bytes, capture_id, seq, record_count, payload_bytes,
         qpc_first, qpc_last, crc_expected, reserved) = h

        if magic != CHUNK_MAGIC or header_bytes != CHUNK.size:
            stop_reason = "invalid_header"
            break

        payload_start = off + CHUNK.size
        payload_end = payload_start + payload_bytes
        trailer_end = payload_end + TRAILER.size
        if trailer_end > len(raw):
            stop_reason = "truncated_chunk"
            break

        trailer = TRAILER.unpack_from(raw, payload_end)
        if (trailer[0] != TRAILER_MAGIC or trailer[1] != crc_expected or
                trailer[2] != payload_bytes):
            stop_reason = "invalid_trailer"
            break

        header_zero_crc = bytearray(raw[off:off + CHUNK.size])
        struct.pack_into("<I", header_zero_crc, 56, 0)
        calculated = crc32c(bytes(header_zero_crc) + raw[payload_start:payload_end])
        if calculated != crc_expected:
            stop_reason = "crc_mismatch"
            break

        if payload_bytes != record_count * EVENT.size:
            stop_reason = "record_size_mismatch"
            break

        events = [
            parse_event(raw[payload_start + i * EVENT.size:
                            payload_start + (i + 1) * EVENT.size])
            for i in range(record_count)
        ]
        chunks.append({
            "schema_major": major,
            "schema_minor": minor,
            "capture_id": capture_id,
            "chunk_seq": seq,
            "qpc_first": qpc_first,
            "qpc_last": qpc_last,
            "events": events,
            "source_file": path.name,
        })
        off = trailer_end

    return chunks, {
        "source_file": path.name,
        "file_bytes": len(raw),
        "valid_bytes": off,
        "tail_bytes": len(raw) - off,
        "stop_reason": stop_reason,
        "valid_chunk_count": len(chunks),
    }


def iter_chunks(path: Path):
    chunks, _ = scan_chunks(path)
    yield from chunks


def read_capture_status(capture_dir: Path):
    status_path = capture_dir / "capture_status.json"
    if not status_path.is_file():
        return None
    try:
        value = json.loads(status_path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def collect_capture_chunks(path: Path):
    path = path.resolve()
    status = None
    if path.is_dir():
        files = sorted(path.glob("events_*.bbx"))
        status = read_capture_status(path)
    else:
        files = [path]

    all_chunks = []
    file_scans = []
    for file in files:
        chunks, scan = scan_chunks(file)
        file_scans.append(scan)
        all_chunks.extend(chunks)

    by_seq = {}
    duplicate_chunk_seq_count = 0
    for chunk in all_chunks:
        seq = int(chunk["chunk_seq"])
        if seq in by_seq:
            duplicate_chunk_seq_count += 1
            continue
        by_seq[seq] = chunk

    chunks = [by_seq[seq] for seq in sorted(by_seq)]
    chunk_seq_gap_count = 0
    if chunks:
        first_seq = int(chunks[0]["chunk_seq"])
        if first_seq > 0:
            chunk_seq_gap_count += first_seq
        for left, right in zip(chunks, chunks[1:]):
            delta = int(right["chunk_seq"]) - int(left["chunk_seq"])
            if delta > 1:
                chunk_seq_gap_count += delta - 1

    capture_ids = sorted({int(c["capture_id"]) for c in chunks})
    damaged_file_count = sum(1 for s in file_scans if s["tail_bytes"] != 0)
    overwrite_count = int((status or {}).get("retention_overwrite_count", 0) or 0)

    retention_complete = (
        overwrite_count == 0 and
        chunk_seq_gap_count == 0 and
        duplicate_chunk_seq_count == 0 and
        damaged_file_count == 0 and
        len(capture_ids) <= 1
    )

    return chunks, {
        "input_kind": "directory" if path.is_dir() else "file",
        "segment_file_count": len(files),
        "capture_status": status,
        "file_scans": file_scans,
        "capture_ids": capture_ids,
        "duplicate_chunk_seq_count": duplicate_chunk_seq_count,
        "chunk_seq_gap_count": chunk_seq_gap_count,
        "damaged_file_count": damaged_file_count,
        "retention_overwrite_count": overwrite_count,
        "retention_complete": retention_complete,
        "first_chunk_seq": int(chunks[0]["chunk_seq"]) if chunks else None,
        "last_chunk_seq": int(chunks[-1]["chunk_seq"]) if chunks else None,
    }


def summarize(events):
    s = {
        "readback_request_count": 0,
        "readback_requested_bytes": 0,
        "readback_copy_count": 0,
        "readback_copy_bytes": 0,
        "backing_commit_success": 0,
        "backing_commit_failure": 0,
        "known_guest_frames": set(),
        "present_count": 0,
        "reused_present_count": 0,
        "orphan_present_count": 0,
        "cpu_gpu_region_marker_count": 0,
        "gpu_query_available_count": 0,
        "gpu_query_unknown_period_count": 0,
        "gpu_duration_ns_total": 0.0,
        "gpu_duration_ns_by_category": {},
        "gpu_query_count_by_category": {},
        "loss_count": 0,
    }

    # Startup capability site=Unknown/payload=DurationQpc carries QPC frequency.
    qpc_frequency = 0
    for e in events:
        if (e["event_id"] == EV_CAPABILITY and e.get("site_id", 0) == 0 and
                e.get("payload_kind", 0) == 1 and e.get("arg0", 0) > 0):
            qpc_frequency = int(e["arg0"])
            break
    s["qpc_frequency"] = qpc_frequency
    s["cpu_duration_ms_by_site"] = {}
    s["cpu_scope_end_count_by_site"] = {}

    # Observer-effect diagnostics. The implementation specification names 8192 events/s
    # as the typical budget and 65536 events/s as the burst ceiling. CLEAN1 reports
    # both rates rather than dropping arbitrary records here: a producer-side limiter
    # must preserve Begin/End pairing and is therefore not silently invented.
    s["event_rate_typical_budget_eps"] = 8192
    s["event_rate_burst_budget_eps"] = 65536
    qpcs = sorted(int(e.get("qpc", 0)) for e in events if int(e.get("qpc", 0)) >= 0)
    if qpc_frequency > 0 and len(qpcs) >= 2 and qpcs[-1] > qpcs[0]:
        span_ticks = qpcs[-1] - qpcs[0]
        s["event_rate_duration_s"] = float(span_ticks) / float(qpc_frequency)
        s["event_rate_mean_eps"] = float(len(qpcs)) * float(qpc_frequency) / float(span_ticks)

        # Exact maximum event count in any QPC-frequency-wide (1 second) window.
        left = 0
        peak = 0
        for right, tick in enumerate(qpcs):
            while left <= right and tick - qpcs[left] >= qpc_frequency:
                left += 1
            peak = max(peak, right - left + 1)
        s["event_rate_peak_1s_count"] = peak
    else:
        s["event_rate_duration_s"] = 0.0
        s["event_rate_mean_eps"] = 0.0
        s["event_rate_peak_1s_count"] = len(qpcs) if qpc_frequency > 0 else 0

    s["event_rate_mean_over_typical_budget"] = (
        s["event_rate_mean_eps"] > float(s["event_rate_typical_budget_eps"])
    )
    s["event_rate_peak_over_burst_budget"] = (
        s["event_rate_peak_1s_count"] > s["event_rate_burst_budget_eps"]
    )

    # queue_id -> (timestampPeriod ns/tick, validBits)
    queue_caps = {}
    # submit_id -> {tick, queue_id, scheduler_id, frame_hint}
    submits = {}
    # region op id -> metadata assembled from begin/end
    regions = {}

    for e in events:
        eid = e["event_id"]
        flags = e["flags"]

        if (flags & (1 << 1)) and e.get("payload_kind", 0) == 1 and qpc_frequency > 0:
            site = str(e.get("site_id", 0))
            duration_ms = (float(e.get("arg2", 0)) * 1000.0) / float(qpc_frequency)
            s["cpu_duration_ms_by_site"][site] =                 s["cpu_duration_ms_by_site"].get(site, 0.0) + duration_ms
            s["cpu_scope_end_count_by_site"][site] =                 s["cpu_scope_end_count_by_site"].get(site, 0) + 1

        if eid == EV_CAPABILITY:
            valid_bits = int(e["arg0"] & 0xFFFF)
            period_bits = int(e["arg1"] & 0xFFFFFFFF)
            period_ns = struct.unpack("<f", struct.pack("<I", period_bits))[0]
            queue_id = int(e["arg2"] & 0xFFFFFFFF)
            if valid_bits > 0 and period_ns > 0:
                queue_caps[queue_id] = (period_ns, valid_bits)

        elif eid == EV_SUBMIT and (flags & ((1 << 0) | (1 << 1))) == 0:
            queue_id = int((e["arg2"] >> 32) & 0xFFFFFFFF)
            scheduler_id = int(e["arg2"] & 0xFFFFFFFF)
            submits[int(e["arg1"])] = {
                "tick": int(e["arg0"]),
                "queue_id": queue_id,
                "scheduler_id": scheduler_id,
                "frame_hint": int(e["frame_hint"]),
            }

        elif eid == EV_FRAME_SUBMIT:
            if e["frame_hint"] != 0:
                s["known_guest_frames"].add(e["frame_hint"])

        elif eid == EV_FRAME_PRESENT:
            s["present_count"] += 1
            if flags & FLAG_REUSED:
                s["reused_present_count"] += 1
            if e["frame_hint"] == 0:
                s["orphan_present_count"] += 1
            # Present never creates a guest frame identity.

        elif eid == EV_READBACK_REQUEST:
            s["readback_request_count"] += 1
            s["readback_requested_bytes"] += e["arg0"]

        elif eid == EV_READBACK_COPY:
            s["readback_copy_count"] += 1
            s["readback_copy_bytes"] += e["arg0"]

        elif eid == EV_BACKING_COMMIT:
            if flags & FLAG_SUCCESS:
                s["backing_commit_success"] += 1
            else:
                s["backing_commit_failure"] += 1

        elif eid == EV_GPU_REGION:
            s["cpu_gpu_region_marker_count"] += 1
            if flags & (1 << 0):  # BEGIN
                regions[e["op_id"]] = {
                    "category": int(e["arg0"]),
                    "bytes": int(e["arg1"]),
                    "resource_token": int(e["arg2"]),
                    "frame_hint": int(e["frame_hint"]),
                }
            elif flags & (1 << 1):  # END, parent_id points at BEGIN op_id
                region = regions.setdefault(e["parent_id"], {})
                region.update({
                    "command_buffer_id": int(e["arg0"]),
                    "submit_id": int(e["arg1"]),
                    "tick": int(e["arg2"]),
                })

        elif eid == EV_GPU_QUERY_RESULT and (flags & FLAG_AVAILABLE):
            s["gpu_query_available_count"] += 1
            queue_id = int((e["arg0"] >> 32) & 0xFFFFFFFF)
            category = int((e["arg0"] >> 16) & 0xFFFF)
            valid_bits = int(e["arg0"] & 0xFFFF)
            start_tick = int(e["arg1"])
            end_tick = int(e["arg2"])

            cap = queue_caps.get(queue_id)
            if cap is None:
                s["gpu_query_unknown_period_count"] += 1
                continue

            period_ns, cap_valid_bits = cap
            valid_bits = min(valid_bits, cap_valid_bits)
            if valid_bits <= 0:
                s["gpu_query_unknown_period_count"] += 1
                continue

            mask = (1 << valid_bits) - 1 if valid_bits < 64 else 0xFFFFFFFFFFFFFFFF
            delta_ticks = (end_tick - start_tick) & mask
            duration_ns = float(delta_ticks) * float(period_ns)

            key = str(category)
            s["gpu_duration_ns_total"] += duration_ns
            s["gpu_duration_ns_by_category"][key] = \
                s["gpu_duration_ns_by_category"].get(key, 0.0) + duration_ns
            s["gpu_query_count_by_category"][key] = \
                s["gpu_query_count_by_category"].get(key, 0) + 1

            # Parent region/submit association is optional for duration, but retained for
            # downstream frame_cost.csv. Missing association stays unknown.
            region = regions.get(e["parent_id"])
            if region is not None:
                submit = submits.get(region.get("submit_id"))
                if submit is not None:
                    region["queue_id"] = submit["queue_id"]
                    region["scheduler_id"] = submit["scheduler_id"]

        elif eid == EV_LOSS:
            s["loss_count"] += e["arg0"]

    s["known_guest_frame_count"] = len(s.pop("known_guest_frames"))
    s["capture_loss_free"] = s["loss_count"] == 0
    s["gpu_duration_ms_total"] = s.pop("gpu_duration_ns_total") / 1_000_000.0
    s["gpu_duration_ms_by_category"] = {
        k: v / 1_000_000.0 for k, v in s.pop("gpu_duration_ns_by_category").items()
    }
    s["submit_identity_count"] = len(submits)
    s["gpu_region_identity_count"] = len(regions)
    return s



def make_test_chunk(events, seq=0, capture_id=1234):
    payload = b"".join(EVENT.pack(
        e.get("qpc", 1), e.get("op_id", 1), e.get("parent_id", 0),
        e.get("arg0", 0), e.get("arg1", 0), e.get("arg2", 0),
        e.get("thread_id", 1), e.get("frame_hint", 0),
        e["event_id"], e.get("site_id", 0), e.get("flags", 0),
        e.get("payload_kind", 0)) for e in events)
    qpc_first = events[0].get("qpc", 1) if events else 0
    qpc_last = events[-1].get("qpc", 1) if events else 0
    header = bytearray(CHUNK.pack(
        CHUNK_MAGIC, 1, 0, CHUNK.size, capture_id, seq, len(events), len(payload),
        qpc_first, qpc_last, 0, 0))
    crc = crc32c(bytes(header) + payload)
    struct.pack_into("<I", header, 56, crc)
    trailer = TRAILER.pack(TRAILER_MAGIC, crc, len(payload))
    return bytes(header) + payload + trailer


def self_test():
    fixture = [
        {"event_id": EV_CAPABILITY, "frame_hint": 0, "arg0": 1000000, "arg1": 0,
         "arg2": 0, "flags": 0, "op_id": 0, "parent_id": 0, "qpc": 0,
         "thread_id": 1, "site_id": 0, "payload_kind": 1},
        {"event_id": EV_CAPABILITY, "frame_hint": 0, "arg0": 64,
         "arg1": 1073741824, "arg2": 123, "flags": 0, "op_id": 1,
         "parent_id": 0, "qpc": 1, "thread_id": 1, "site_id": 0,
         "payload_kind": 0},
        {"event_id": EV_SUBMIT, "frame_hint": 77, "arg0": 9, "arg1": 42,
         "arg2": (123 << 32) | 7, "flags": 0, "op_id": 2, "parent_id": 0,
         "qpc": 2, "thread_id": 1, "site_id": 0, "payload_kind": 0},
        {"event_id": EV_FRAME_SUBMIT, "frame_hint": 77, "arg0": 0, "arg1": 0,
         "arg2": 0, "flags": 0},
        {"event_id": EV_READBACK_REQUEST, "frame_hint": 77, "arg0": 4096,
         "arg1": 524288, "arg2": 250, "flags": 0},
        {"event_id": EV_READBACK_COPY, "frame_hint": 77, "arg0": 4096,
         "arg1": 4160, "arg2": 0, "flags": 0},
        {"event_id": EV_BACKING_COMMIT, "frame_hint": 77, "arg0": 4096,
         "arg1": 1, "arg2": 42, "flags": FLAG_SUCCESS},
        {"event_id": EV_FRAME_PRESENT, "frame_hint": 0, "arg0": 0, "arg1": 0,
         "arg2": 0, "flags": 0},
        {"event_id": EV_GPU_REGION, "frame_hint": 77, "arg0": 7, "arg1": 4096,
         "arg2": 0, "flags": 1, "op_id": 30, "parent_id": 0, "qpc": 30,
         "thread_id": 1, "site_id": 0, "payload_kind": 0},
        {"event_id": EV_GPU_REGION, "frame_hint": 77, "arg0": 99, "arg1": 42,
         "arg2": 9, "flags": 2, "op_id": 31, "parent_id": 30, "qpc": 31,
         "thread_id": 1, "site_id": 0, "payload_kind": 0},
        {"event_id": EV_GPU_QUERY_RESULT, "frame_hint": 77,
         "arg0": (123 << 32) | (7 << 16) | 64, "arg1": 100, "arg2": 350,
         "flags": FLAG_AVAILABLE, "op_id": 32, "parent_id": 30, "qpc": 32,
         "thread_id": 1, "site_id": 0, "payload_kind": 0},
        {"event_id": 31, "frame_hint": 77, "arg0": 0, "arg1": 0, "arg2": 5000,
         "flags": 2, "op_id": 40, "parent_id": 39, "qpc": 40,
         "thread_id": 1, "site_id": 185, "payload_kind": 1},
    ]

    summary = summarize(fixture)
    assert summary["readback_request_count"] == 1, summary
    assert summary["readback_requested_bytes"] == 4096, summary
    assert summary["readback_copy_count"] == 1, summary
    assert summary["readback_copy_bytes"] == 4096, summary
    assert summary["backing_commit_success"] == 1, summary
    assert summary["backing_commit_failure"] == 0, summary
    assert summary["known_guest_frame_count"] == 1, summary
    assert summary["orphan_present_count"] == 1, summary
    assert summary["gpu_query_available_count"] == 1, summary
    assert abs(summary["gpu_duration_ms_total"] - 0.0005) < 1e-12, summary
    assert summary["submit_identity_count"] == 1, summary
    assert summary["gpu_region_identity_count"] == 1, summary
    assert abs(summary["cpu_duration_ms_by_site"]["185"] - 5.0) < 1e-12, summary
    assert summary["capture_loss_free"], summary

    rate_fixture = [
        {"event_id": EV_CAPABILITY, "frame_hint": 0, "arg0": 1000, "arg1": 0,
         "arg2": 0, "flags": 0, "op_id": 0, "parent_id": 0, "qpc": 0,
         "thread_id": 1, "site_id": 0, "payload_kind": 1},
        {"event_id": EV_HEARTBEAT, "qpc": 100, "flags": 0},
        {"event_id": EV_HEARTBEAT, "qpc": 500, "flags": 0},
        {"event_id": EV_HEARTBEAT, "qpc": 1000, "flags": 0},
        {"event_id": EV_HEARTBEAT, "qpc": 1500, "flags": 0},
        {"event_id": EV_HEARTBEAT, "qpc": 2000, "flags": 0},
    ]
    rate_summary = summarize(rate_fixture)
    assert abs(rate_summary["event_rate_duration_s"] - 2.0) < 1e-12, rate_summary
    assert abs(rate_summary["event_rate_mean_eps"] - 3.0) < 1e-12, rate_summary
    assert rate_summary["event_rate_peak_1s_count"] == 3, rate_summary
    assert not rate_summary["event_rate_mean_over_typical_budget"], rate_summary
    assert not rate_summary["event_rate_peak_over_burst_budget"], rate_summary

    with_loss = list(fixture)
    with_loss.append({"event_id": EV_LOSS, "frame_hint": 0, "arg0": 3,
                      "arg1": 0, "arg2": 0, "flags": 0})
    loss_summary = summarize(with_loss)
    assert loss_summary["loss_count"] == 3
    assert not loss_summary["capture_loss_free"]

    chunk = make_test_chunk(fixture[:2], seq=0)
    with tempfile.TemporaryDirectory() as td_string:
        td = Path(td_string)

        good = td / "good_tail.bbx"
        good.write_bytes(chunk + b"INCOMPLETE_TAIL")
        parsed, scan = scan_chunks(good)
        assert len(parsed) == 1 and len(parsed[0]["events"]) == 2
        assert scan["tail_bytes"] == len(b"INCOMPLETE_TAIL")
        assert scan["stop_reason"] == "truncated_header"

        corrupt = bytearray(chunk)
        corrupt[64] ^= 0x01
        bad = td / "bad_crc.bbx"
        bad.write_bytes(corrupt)
        parsed_bad, bad_scan = scan_chunks(bad)
        assert parsed_bad == []
        assert bad_scan["stop_reason"] == "crc_mismatch"

        capture = td / "capture"
        capture.mkdir()
        # Physical slot order is intentionally not chronological.
        (capture / "events_000.bbx").write_bytes(make_test_chunk(fixture[:1], seq=0))
        (capture / "events_015.bbx").write_bytes(make_test_chunk(fixture[1:2], seq=1))
        (capture / "events_001.bbx").write_bytes(make_test_chunk(fixture[2:3], seq=2))
        (capture / "capture_status.json").write_text(json.dumps({
            "complete": True,
            "retention_overwrite_count": 0,
            "trigger_snapshot_retention": "PARTIAL_NOT_IMPLEMENTED",
        }), encoding="utf-8")

        ordered, meta = collect_capture_chunks(capture)
        assert [c["chunk_seq"] for c in ordered] == [0, 1, 2], ordered
        assert meta["retention_complete"], meta
        assert meta["chunk_seq_gap_count"] == 0, meta

        # Simulate circular overwrite: startup remains, middle chronology is no longer complete.
        (capture / "events_015.bbx").write_bytes(make_test_chunk(fixture[1:2], seq=10))
        (capture / "capture_status.json").write_text(json.dumps({
            "complete": True,
            "retention_overwrite_count": 1,
            "trigger_snapshot_retention": "PARTIAL_NOT_IMPLEMENTED",
        }), encoding="utf-8")
        _, overwritten = collect_capture_chunks(capture)
        assert not overwritten["retention_complete"], overwritten
        assert overwritten["retention_overwrite_count"] == 1, overwritten
        assert overwritten["chunk_seq_gap_count"] > 0, overwritten

    return {
        "pass": True,
        "summary": summary,
        "rate_summary": rate_summary,
        "loss_summary": loss_summary,
        "tail_tolerance": True,
        "event_rate_diagnostics": True,
        "crc_rejection": True,
        "multi_segment_sequence_order": True,
        "retention_overwrite_detection": True,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("capture", nargs="?")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        print(json.dumps(self_test(), indent=2))
        return 0

    if not args.capture:
        parser.error("capture file or directory required")

    chunks, protocol = collect_capture_chunks(Path(args.capture))
    events = []
    for chunk in chunks:
        events.extend(chunk["events"])

    result = summarize(events)
    status = protocol.get("capture_status")
    status_loss_total = (
        int(status.get("event_loss_total", 0) or 0)
        if isinstance(status, dict) else 0
    )
    if status_loss_total > result["loss_count"]:
        result["loss_count"] = status_loss_total
    event_loss_free = result["loss_count"] == 0
    result["event_loss_free"] = event_loss_free
    result["capture_loss_free"] = event_loss_free and bool(protocol["retention_complete"])
    result["retention"] = protocol
    result["valid_chunks"] = len(chunks)
    result["event_count"] = len(events)
    result["capture_complete"] = (
        bool(status.get("complete")) if isinstance(status, dict) else None
    )

    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
