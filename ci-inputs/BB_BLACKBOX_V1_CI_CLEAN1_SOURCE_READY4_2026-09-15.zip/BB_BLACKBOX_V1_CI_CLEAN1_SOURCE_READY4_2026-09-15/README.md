# BB BLACKBOX V1 CI CLEAN1 — SOURCE_READY4

This is the locally-qualified, self-contained source/integration package for the Bloodborne/shadPS4 UMA BLACKBOX diagnostic build. It is **not runtime-approved**.

Authoritative integration patch:

`integration/BLACKBOX_V1_CI_CLEAN1_CORE_SAFE.patch`

Frozen baseline:

`diegolix29/shadPS4@03d62ad22438344f1dcd38c5b5e44f660b564b92`

Exact accepted parent:

`evidence/accepted_parent/INTEGRATED_R3_SAVEFIX_S1.patch`

Required parent SHA256:

`92ee02584cae06cc4feace76dcbfdaadcca225e3a005b1038246850fa154c485`

The parent bytes were recovered from the frozen S1 checkpoint SHA256
`cdaeea529c3290c297f856f42ccbc03b76c58493af9256bb91eabf1453f3bf07`.
Its outer manifest verified 27/27 entries and the nested build-package manifest verified 33/33 entries.

## SOURCE_READY4 changes

- Windows CI now pins the LLVM 19.1.1 installer by exact byte size and SHA256 before installation.
- Successful Windows CI assembles a runnable Qt package with `windeployqt`, `qt.conf`, plugins, recorder, decoder, launcher and build/replay evidence; it does not publish a bare `shadPS4.exe` as the owner-facing artifact.
- `ScopedEvent` no longer emits an orphan END if its BEGIN could not be recorded.
- The decoder reports mean event rate and exact maximum event count in any 1-second QPC window against the implementation-spec reference budgets (8192/s typical, 65536/s burst).
- No producer-side general event-rate limiter was invented because naïve dropping can break Begin/End pairing. This remains explicitly partial and is evaluated by the observer-effect gate.
- Trigger-centered snapshot retention also remains explicitly `PARTIAL_NOT_IMPLEMENTED`.

On a clean exact checkout, apply the embedded parent and CLEAN1 source with:

```powershell
./ci/APPLY_CLEAN1_SOURCE_READY.ps1 -RepoRoot <repo>
```

The applicator fails closed on baseline identity, dirty source, parent hash, parent apply, integration-patch structure, integration apply, decoder self-test and semantic gates. GitHub Actions independently replays the accepted parent from the frozen baseline before the Tier-B build.

The authoritative external build gate remains:

`windows-2022 + Visual Studio 2022 + clang-cl 19.1.1 + Qt 6.9.3 msvc2022_64`

Do not run a representative Bloodborne capture before exact replay, Windows build and CONTROL-vs-BLACKBOX observer-effect smoke pass.

`RUNTIME_TEST_ALLOWED=false`
