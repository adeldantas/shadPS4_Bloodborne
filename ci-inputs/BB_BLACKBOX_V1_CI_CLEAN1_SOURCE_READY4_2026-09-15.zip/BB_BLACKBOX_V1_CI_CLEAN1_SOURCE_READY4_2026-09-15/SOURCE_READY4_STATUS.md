# BLACKBOX V1 CI CLEAN1 — SOURCE_READY4 STATUS

Date: 2026-09-15

## Verdict

**SOURCE_READY4 QUALIFIED LOCALLY; EXACT PARENT EMBEDDED; RUNNABLE WINDOWS PACKAGING HARDENED; FULL GIT REPLAY + WINDOWS BUILD PENDING.**  
**RUNTIME_TEST_ALLOWED=false.**

This is a source/integration candidate for the authoritative Windows CI gate, not a Bloodborne runtime build.

## Closed in SOURCE_READY4

- Exact `R3-SAVEFIX-S1` bytes remain embedded and SHA-gated to `92ee02584cae06cc4feace76dcbfdaadcca225e3a005b1038246850fa154c485`.
- LLVM 19.1.1 installer is now fail-closed on exact size `351794030` and SHA256 `95f03b6a8a0049e29898b0fadf84a0ea252f2e7f1b36db15a81aae11e912f675` before installation.
- Windows CI packaging follows the frozen shadPS4 Qt deployment model: `windeployqt`, `qt.conf`, Qt plugins/DLLs, emulator, recorder, decoder and a top-level `RUN_BLACKBOX.cmd` are assembled into one owner-facing ZIP.
- The package gate requires `Qt6Core.dll`, `Qt6Gui.dll`, `Qt6Widgets.dll` and `qtplugins/platforms/qwindows.dll`; a compile-only artifact cannot masquerade as runnable output.
- `ScopedEvent::~ScopedEvent()` now suppresses END when BEGIN returned `op_id=0`, preventing fabricated orphan scope termination.
- Decoder now reports `event_rate_mean_eps`, `event_rate_peak_1s_count`, and budget-exceeded flags for 8192/s typical and 65536/s burst reference limits.

## Local validation

All current local gates PASS:

- Python syntax.
- Decoder self-test, including event-rate arithmetic.
- Semantic-gate regression tests.
- SAFE patch parser.
- Patch-structure gate.
- GitHub workflow YAML parse.
- Exact embedded parent SHA/provenance.
- Portable C++23 recorder compile with `-Wall -Wextra -Werror`.
- Recorder link and expected no-argument smoke exit.
- Static CI packaging/toolchain/safety checks.

See `tests/SOURCE_READY4_LOCAL_VALIDATION.json`.

## Safety state retained

- `C_WRITEBACK_UNSAFE` retained.
- GPU-modified GC writeback OFF.
- BufferGC eviction OFF.
- DISCARD_STALE OFF.
- No new global VMM reservation protocol.
- C1-C6 unintegrated.
- SaveFix mandatory.
- GPU profiler does not introduce WAIT_BIT, waitIdle or Finish for profiling.
- Shared-memory 32/64-bit atomics remain compile-time lock-free requirements.
- Raw capture cap remains 512 MiB; startup segment pinned; retention overwrite/gaps invalidate loss-free status.

## Explicit partials

These are not hidden as PASS:

1. General producer-side event-rate limiter: **NOT IMPLEMENTED**. The decoder measures actual rate, and observer-effect acceptance must reject an excessive capture. A limiter was not improvised because arbitrary drops can corrupt Begin/End pairing.
2. Trigger-centered pinned snapshot retention: **PARTIAL_NOT_IMPLEMENTED**. Bounded startup + rolling retention remains implemented.

Neither partial permits representative runtime testing by itself.

## Remaining authoritative gates

1. Complete frozen `03d62ad22438344f1dcd38c5b5e44f660b564b92` Git checkout: execute `VERIFY_EXACT_PARENT_REPLAY.ps1`, including full `git apply --check` of parent and CLEAN1.
2. `windows-2022 + VS2022 + clang-cl 19.1.1 + Qt 6.9.3` build: emit both executables and the self-contained runtime ZIP.
3. CONTROL vs BLACKBOX observer-effect smoke: mean overhead `<0.20 ms/frame`, P95 `<0.50 ms`, no event loss/retention invalidation, and event-rate diagnostics reviewed.
4. Only then permit the representative Bloodborne capture.

The currently connected `diegolix29/shadPS4` GitHub repository is read-only for this session (`pull=true`, `push=false`), so no branch or Actions run is falsely claimed.

`RUNTIME_TEST_ALLOWED=false`
